# Anti-Dengue Smart Assistant (Android 9+ Native Kotlin Project)

A native Android (Kotlin + Jetpack Compose + Material 3) companion assistant designed for **Android 9 (API 28)** on Oppo smartphones to assist with daily 20-activity workflows alongside the official Punjab Anti-Dengue app (PITB v9.4.0).

## Core Capabilities & Safety Guarantees

- **20-Activity Persistent Dashboard**: Tracks Completed, Saved, Submitted, and Pending counts with Start / Pause / Resume controls backed by local SQLite storage (`AssistantDatabaseHelper`).
- **Save All → Submit Once + Optional Immediate Submit**: Supports completing and saving all 20 activities locally first, reviewing the full batch on a dedicated confirmation screen, and submitting once—with duplicate-submission locking.
- **Genuine Before / After Photo Workflow**:
  - Uses the official PITB app's camera workflow for both photos.
  - Starts a monotonic 2-minute (`120s`) Foreground Service countdown (`PhotoTimerForegroundService`) after the Before photo so you can do other work while waiting.
  - Fires a high-priority audible notification when 2 minutes have elapsed.
  - Never generates, edits, reuses, or falsifies photos, timestamps, or GPS metadata.
- **Target-Scoped AccessibilityService (`DengueAccessibilityService`)**:
  - Does **not** hardcode or guess the PITB package ID—detects installed apps via `InstalledAppsDetector` and lets you select the exact app.
  - Strictly ignores all unrelated apps (`rootPkg != targetPackage`).
  - Automatically pauses and asks for manual assistance on unfamiliar screens (`UNFAMILIAR_SCREEN`) or login/OTP screens (`AUTH_OR_OTP_SCREEN`).
  - Never reads or stores passwords, OTPs, or login credentials.
- **Honest Integration Note**: Live UI automation against PITB v9.4.0 has **not** been tested on-device in this build environment. An optional **Screen Label Inspector** is included in the *Fields* tab so you can calibrate exact PITB v9.4.0 view IDs/labels safely on your phone.

## Phone-Only Build Instructions (No PC Required)

See `INSTALLATION_AND_CHECKLIST.md` for:
1. Building a Debug APK using **GitHub Mobile Browser + GitHub Actions** (using the included `.github/workflows/build-apk.yml`) — zero laptop required.
2. Alternative on-phone building with **AndroidIDE / Termux**.
3. Oppo ColorOS Android 9 installation, Accessibility permission, and battery optimization steps.
4. Full pre-field verification checklist.
