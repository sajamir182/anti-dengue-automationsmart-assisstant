# Keep AccessibilityService & Service classes intact
-keep class com.antidengue.assistant.accessibility.** { *; }
-keep class com.antidengue.assistant.timer.** { *; }
