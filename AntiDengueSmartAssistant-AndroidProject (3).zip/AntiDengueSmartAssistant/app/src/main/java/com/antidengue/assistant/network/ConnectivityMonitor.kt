package com.antidengue.assistant.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NetworkStatus(
    val isConnected: Boolean = false,
    val isValidated: Boolean = false,
    val transportLabel: String = "Offline"
)

class ConnectivityMonitor(context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _status = MutableStateFlow(readCurrentStatus())
    val status: StateFlow<NetworkStatus> = _status.asStateFlow()

    private var registered = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _status.value = readCurrentStatus()
        }

        override fun onLost(network: Network) {
            _status.value = readCurrentStatus()
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            _status.value = evaluateCapabilities(networkCapabilities)
        }
    }

    fun startMonitoring() {
        if (registered) return
        _status.value = readCurrentStatus()
        runCatching {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
            registered = true
        }
    }

    fun refreshNow(): NetworkStatus {
        val current = readCurrentStatus()
        _status.value = current
        return current
    }

    private fun readCurrentStatus(): NetworkStatus {
        val activeNetwork = connectivityManager.activeNetwork ?: return NetworkStatus(
            isConnected = false,
            isValidated = false,
            transportLabel = "Offline (No active network)"
        )
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return NetworkStatus(
            isConnected = false,
            isValidated = false,
            transportLabel = "Offline"
        )
        return evaluateCapabilities(caps)
    }

    private fun evaluateCapabilities(caps: NetworkCapabilities): NetworkStatus {
        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val isValidated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Network"
        }
        val label = when {
            !hasInternet -> "Offline"
            isValidated -> "$transport (Online)"
            else -> "$transport (Unverified Internet)"
        }
        return NetworkStatus(
            isConnected = hasInternet,
            isValidated = isValidated,
            transportLabel = label
        )
    }
}
