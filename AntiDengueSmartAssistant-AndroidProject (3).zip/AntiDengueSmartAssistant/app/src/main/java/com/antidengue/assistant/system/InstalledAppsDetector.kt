package com.antidengue.assistant.system

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

data class DetectedInstalledApp(
    val packageName: String,
    val appLabel: String,
    val versionName: String,
    val isLikelyAntiDengueMatch: Boolean
)

object InstalledAppsDetector {

    private val keywords = listOf("dengue", "pitb", "punjab", "anti", "vector")

    fun loadInstalledLauncherApps(context: Context): List<DetectedInstalledApp> {
        val pm = context.packageManager
        val selfPkg = context.packageName
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
        val seenPackages = HashSet<String>()
        val apps = mutableListOf<DetectedInstalledApp>()

        for (info in resolveInfos) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == selfPkg || !seenPackages.add(pkg)) continue

            val label = info.loadLabel(pm)?.toString()?.trim().orEmpty().ifEmpty { pkg }
            val version = runCatching {
                pm.getPackageInfo(pkg, 0).versionName ?: "Unknown"
            }.getOrDefault("Unknown")

            val combinedLower = "$label $pkg".lowercase()
            val isLikely = keywords.any { combinedLower.contains(it) }

            apps.add(
                DetectedInstalledApp(
                    packageName = pkg,
                    appLabel = label,
                    versionName = version,
                    isLikelyAntiDengueMatch = isLikely
                )
            )
        }

        return apps.sortedWith(
            compareByDescending<DetectedInstalledApp> { it.isLikelyAntiDengueMatch }
                .thenBy { it.appLabel.lowercase() }
        )
    }
}
