package com.antidengue.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.antidengue.assistant.data.model.ActivityStatus
import com.antidengue.assistant.data.model.SubmissionMode
import com.antidengue.assistant.ui.components.ActivePhotoTimerBanner
import com.antidengue.assistant.ui.components.ActivityStatusLabel
import com.antidengue.assistant.ui.components.NetworkWarningBanner
import com.antidengue.assistant.ui.theme.BorderHairline
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.viewmodel.AssistantViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ActivityDetailScreen(
    vm: AssistantViewModel,
    activityNumber: Int,
    onBack: () -> Unit
) {
    val activities by vm.activities.collectAsState()
    val activity = activities.firstOrNull { it.activityNumber == activityNumber } ?: return
    val timerState by vm.timerState.collectAsState()
    val networkStatus by vm.networkStatus.collectAsState()
    val submissionMode by vm.submissionMode.collectAsState()

    var titleInput by remember(activity.activityNumber, activity.title) { mutableStateOf(activity.title) }
    var noteInput by remember(activity.activityNumber, activity.note) { mutableStateOf(activity.note) }
    var immediateConfirmNote by remember(activity.activityNumber) {
        mutableStateOf("Confirmed on official PITB screen")
    }

    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) {
                Text("← Back to Dashboard")
            }
            ActivityStatusLabel(status = activity.status)
        }

        NetworkWarningBanner(networkStatus = networkStatus)

        ActivePhotoTimerBanner(
            timerState = timerState,
            onOpenOfficialApp = { vm.openOfficialPitbApp() },
            onOpenActivity = {}
        )

        // Personal Reference Labels (Never auto-invented)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Activity Label & Location Note (Optional)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = { Text("Activity Title / Site") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = noteInput,
                    onValueChange = { noteInput = it },
                    label = { Text("Your Field Note") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { vm.updateActivityDetails(activityNumber, titleInput, noteInput) },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Save Label Locally")
                }
            }
        }

        // Step 1: Genuine Before Photo
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Step 1 · Genuine Before Photo",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Open the official Punjab Anti-Dengue app and take a genuine Before photo using its built-in camera. Never reuse or edit photos.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (activity.beforePhotoCapturedAtMs != null) {
                    Text(
                        text = "Before photo recorded at ${formatTime(activity.beforePhotoCapturedAtMs)}",
                        color = PrimaryGreen,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { vm.openOfficialPitbApp() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Open PITB Camera")
                    }
                    Button(
                        onClick = { vm.markBeforePhotoCaptured(activityNumber) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("Before Captured (Start 2m)")
                    }
                }
            }
        }

        // Step 2: 2-Minute Interval & Genuine After Photo
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Step 2 · 2-Minute Wait & Genuine After Photo",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                val timerRunningForThis = timerState.isRunning && timerState.activityNumber == activityNumber
                if (timerRunningForThis) {
                    val mins = timerState.remainingSeconds / 60
                    val secs = timerState.remainingSeconds % 60
                    Text(
                        text = String.format("Countdown: %02d:%02d remaining", mins, secs),
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309)
                    )
                    Text(
                        text = "You can do other work now. An audible chime and notification will alert you when 2 minutes finish.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (activity.afterPhotoCapturedAtMs != null) {
                    Text(
                        text = "After photo recorded at ${formatTime(activity.afterPhotoCapturedAtMs)}",
                        color = PrimaryGreen,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                val canMarkAfter = activity.beforePhotoCapturedAtMs != null && !timerRunningForThis
                Button(
                    onClick = { vm.markAfterPhotoCaptured(activityNumber) },
                    enabled = canMarkAfter,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text(
                        if (timerRunningForThis) {
                            "Wait for 2-Minute Countdown to Finish"
                        } else {
                            "Confirm Genuine After Photo Captured"
                        }
                    )
                }
            }
        }

        // Step 3: User Review & Verify Save / Submit
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Step 3 · Review & Verify Official Save",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = activity.userReviewedBeforeSave,
                        onCheckedChange = { vm.setActivityReviewed(activityNumber, it) }
                    )
                    Text(
                        text = "I have reviewed all inspection fields and genuine photos in the official PITB app.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                val readyToConfirm = activity.beforePhotoCapturedAtMs != null &&
                    activity.afterPhotoCapturedAtMs != null &&
                    activity.userReviewedBeforeSave

                if (submissionMode == SubmissionMode.SAVE_ALL) {
                    Button(
                        onClick = {
                            vm.confirmActivitySaved(activityNumber)
                        },
                        enabled = readyToConfirm && activity.status != ActivityStatus.SUBMITTED,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("Verify Activity #$activityNumber Saved in PITB App")
                    }
                } else {
                    OutlinedTextField(
                        value = immediateConfirmNote,
                        onValueChange = { immediateConfirmNote = it },
                        label = { Text("Official App Confirmation Message") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            vm.confirmSingleActivitySubmitted(activityNumber, immediateConfirmNote)
                        },
                        enabled = readyToConfirm && networkStatus.isConnected,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("Verify Immediate Submission Succeeded")
                    }
                }

                OutlinedButton(
                    onClick = {
                        vm.markNeedsAttention(
                            activityNumber,
                            "User flagged for manual review or network retry."
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Flag as Needs Attention / Error")
                }
            }
        }
    }
}

private fun formatTime(epochMs: Long): String {
    return SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(epochMs))
}
