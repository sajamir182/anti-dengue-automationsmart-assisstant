package com.antidengue.assistant.data.model

/**
 * Represents a repeated non-sensitive form field value explicitly entered
 * and confirmed by the user. The assistant never invents inspection results
 * or fills password/OTP fields.
 */
data class ConfirmedFieldTemplate(
    val id: Long = 0L,
    val fieldLabelHint: String,
    val targetViewIdHint: String = "",
    val confirmedValue: String,
    val enabledForAutoFill: Boolean = false,
    val confirmedByUser: Boolean = false,
    val updatedAtMs: Long = System.currentTimeMillis()
)
