package com.antidengue.assistant.accessibility

import com.antidengue.assistant.data.model.AssistantRunState
import com.antidengue.assistant.data.model.ConfirmedFieldTemplate
import com.antidengue.assistant.data.repository.AssistantRepository

data class PlannedFieldFill(
    val targetViewId: String,
    val labelHint: String,
    val confirmedValue: String
)

object AutomationCoordinator {

    fun matchTemplatesForEmptyFields(
        nodes: List<AccessibleNodeDescriptor>,
        templates: List<ConfirmedFieldTemplate>
    ): List<PlannedFieldFill> {
        val activeTemplates = templates.filter { it.enabledForAutoFill && it.confirmedByUser && it.confirmedValue.isNotBlank() }
        if (activeTemplates.isEmpty()) return emptyList()

        val plans = mutableListOf<PlannedFieldFill>()
        for (node in nodes) {
            if (!node.isEditable || PitbScreenClassifier.isSensitiveCredentialNode(node)) continue
            // Only fill empty fields; never overwrite data the user already entered manually.
            if (node.text.isNotBlank()) continue

            val matched = activeTemplates.firstOrNull { tpl ->
                val idMatch = tpl.targetViewIdHint.isNotBlank() &&
                    node.viewIdResourceName.contains(tpl.targetViewIdHint, ignoreCase = true)
                val hintMatch = tpl.fieldLabelHint.isNotBlank() &&
                    node.combinedHint.contains(tpl.fieldLabelHint, ignoreCase = true)
                idMatch || hintMatch
            }
            if (matched != null) {
                plans.add(
                    PlannedFieldFill(
                        targetViewId = node.viewIdResourceName,
                        labelHint = matched.fieldLabelHint,
                        confirmedValue = matched.confirmedValue
                    )
                )
            }
        }
        return plans
    }

    fun handleScreenClassification(
        repository: AssistantRepository,
        screenType: PitbScreenType
    ) {
        val currentRunState = repository.runState.value
        val activeNum = repository.activeActivityNumber.value

        when (screenType) {
            PitbScreenType.AUTH_OR_OTP_SCREEN -> {
                if (currentRunState == AssistantRunState.RUNNING) {
                    repository.setRunState(
                        AssistantRunState.PAUSED,
                        "Paused on login/OTP screen. Assistant never interacts with credentials."
                    )
                }
            }
            PitbScreenType.UNFAMILIAR_SCREEN -> {
                if (currentRunState == AssistantRunState.RUNNING) {
                    repository.setRunState(
                        AssistantRunState.PAUSED_UNFAMILIAR_SCREEN,
                        "Stopped on unfamiliar screen while assisting Activity #$activeNum."
                    )
                    repository.setUnfamiliarScreenPrompt(
                        "The current screen in the official app was not recognized safely. Please inspect it manually and tap Resume when ready."
                    )
                }
            }
            PitbScreenType.ERROR_OR_NETWORK_FAILURE -> {
                repository.markActivityNeedsAttention(
                    activeNum,
                    "Official app showed a network or validation error. Verify connectivity before retrying."
                )
                repository.setRunState(
                    AssistantRunState.PAUSED,
                    "Paused: official app displayed an error or network warning."
                )
            }
            PitbScreenType.BEFORE_PHOTO_STEP -> {
                repository.setAutomationStatusMessage(
                    "Before Photo step detected for Activity #$activeNum. Capture genuine Before photo in the official camera, then confirm in Assistant."
                )
            }
            PitbScreenType.AFTER_PHOTO_STEP -> {
                val timer = repository.timerState.value
                if (timer.isRunning && timer.remainingSeconds > 0) {
                    repository.setAutomationStatusMessage(
                        "Wait ${timer.remainingSeconds}s remaining before taking the genuine After photo for Activity #$activeNum."
                    )
                } else {
                    repository.setAutomationStatusMessage(
                        "After Photo step detected for Activity #$activeNum. Capture genuine After photo now."
                    )
                }
            }
            PitbScreenType.SAVE_CONFIRMATION -> {
                repository.setAutomationStatusMessage(
                    "Save prompt detected for Activity #$activeNum. Review all entries carefully before saving."
                )
            }
            PitbScreenType.SUBMIT_ALL_SCREEN -> {
                repository.setAutomationStatusMessage(
                    "Batch Submit screen detected. Use Assistant Review & Confirm screen to prevent duplicate submissions."
                )
            }
            PitbScreenType.SUCCESS_CONFIRMATION -> {
                repository.setAutomationStatusMessage(
                    "Official app showed a confirmation message. Verify Activity #$activeNum status in Assistant."
                )
            }
            PitbScreenType.ACTIVITY_FORM -> {
                repository.setAutomationStatusMessage(
                    "Activity #$activeNum form detected. Confirmed repeated fields can be assisted; enter unique inspection observations manually."
                )
            }
            PitbScreenType.HOME_OR_ACTIVITY_LIST -> {
                repository.setAutomationStatusMessage(
                    "Official app list detected. Ready to proceed with Activity #$activeNum."
                )
            }
        }
    }
}
