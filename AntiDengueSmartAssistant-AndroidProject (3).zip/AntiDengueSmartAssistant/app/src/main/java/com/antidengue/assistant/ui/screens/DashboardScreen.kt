package com.antidengue.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.antidengue.assistant.data.model.AssistantRunState
import com.antidengue.assistant.data.model.DailyActivityRecord
import com.antidengue.assistant.data.model.SubmissionMode
import com.antidengue.assistant.ui.components.ActivePhotoTimerBanner
import com.antidengue.assistant.ui.components.ActivityStatusLabel
import com.antidengue.assistant.ui.components.NetworkWarningBanner
import com.antidengue.assistant.ui.theme.BorderHairline
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.theme.WarningAmber
import com.antidengue.assistant.ui.viewmodel.AssistantViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    vm: AssistantViewModel,
    onOpenActivity: (Int) -> Unit,
    onGoToReviewSubmit: () -> Unit,
    onGoToSetup: () -> Unit
) {
    val dateKey by vm.todayDateKey.collectAsState()
    val summary by vm.summary.collectAsState()
    val activities by vm.activities.collectAsState()
    val runState by vm.runState.collectAsState()
    val submissionMode by vm.submissionMode.collectAsState()
    val targetApp by vm.targetAppConfig.collectAsState()
    val activeNum by vm.activeActivityNumber.collectAsState()
    val statusMsg by vm.automationStatusMessage.collectAsState()
    val networkStatus by vm.networkStatus.collectAsState()
    val timerState by vm.timerState.collectAsState()
    val accessibilityEnabled by vm.isAccessibilityEnabled.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            NetworkWarningBanner(networkStatus = networkStatus)
        }

        item {
            ActivePhotoTimerBanner(
                timerState = timerState,
                onOpenOfficialApp = { vm.openOfficialPitbApp() },
                onOpenActivity = onOpenActivity
            )
        }

        // Progress Overview Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Daily Progress · $dateKey",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "State: ${runState.label} · ${networkStatus.transportLabel}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${summary.progressPercent}%",
                            style = MaterialTheme.typography.headlineSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryGreen
                        )
                    }

                    LinearProgressIndicator(
                        progress = { summary.progressPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = PrimaryGreen
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatCell("Completed", summary.completedCount)
                        StatCell("Saved", summary.savedCount)
                        StatCell("Submitted", summary.submittedCount)
                        StatCell("Pending", summary.pendingCount)
                    }

                    Text(
                        text = statusMsg,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF334155)
                    )
                }
            }
        }

        // Workflow Mode Switcher + Assistant Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Workflow Mode",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SubmissionMode.entries.forEachIndexed { index, mode ->
                            SegmentedButton(
                                selected = submissionMode == mode,
                                onClick = { vm.setSubmissionMode(mode) },
                                shape = SegmentedButtonDefaults.itemShape(
                                    index = index,
                                    count = SubmissionMode.entries.size
                                )
                            ) {
                                Text(
                                    text = if (mode == SubmissionMode.SAVE_ALL) "Save All (20)" else "Immediate",
                                    maxLines = 1
                                )
                            }
                        }
                    }
                    Text(
                        text = submissionMode.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (targetApp.packageName.isNullOrBlank() || !accessibilityEnabled) {
                        OutlinedButton(
                            onClick = onGoToSetup,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (targetApp.packageName.isNullOrBlank()) {
                                    "Step 1: Select Official PITB App in Setup"
                                } else {
                                    "Accessibility Helper Disabled — Tap to Enable in Setup"
                                },
                                color = WarningAmber
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (runState == AssistantRunState.RUNNING) {
                            OutlinedButton(
                                onClick = { vm.pauseAssistant() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Pause")
                            }
                        } else {
                            Button(
                                onClick = { vm.startOrResumeAssistant() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                            ) {
                                Text(
                                    if (runState == AssistantRunState.PAUSED || runState == AssistantRunState.PAUSED_UNFAMILIAR_SCREEN) {
                                        "Resume"
                                    } else {
                                        "Start"
                                    }
                                )
                            }
                        }

                        Button(
                            onClick = { vm.openOfficialPitbApp() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                        ) {
                            Text("Open PITB App")
                        }
                    }

                    if (submissionMode == SubmissionMode.SAVE_ALL && summary.savedCount > 0) {
                        Button(
                            onClick = onGoToReviewSubmit,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                        ) {
                            Text("Review & Submit All (${summary.savedCount} Saved)")
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "20 Daily Activities (Tap an item for guided Before/After photo workflow)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(activities, key = { it.activityNumber }) { activity ->
            ActivityRowCard(
                activity = activity,
                isActivePointer = activity.activityNumber == activeNum,
                onClick = { onOpenActivity(activity.activityNumber) }
            )
        }
    }
}

@Composable
private fun StatCell(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ActivityRowCard(
    activity: DailyActivityRecord,
    isActivePointer: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (isActivePointer) PrimaryGreen else BorderHairline
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(if (isActivePointer) 2.dp else 1.dp, borderColor),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = "${activity.activityNumber}. ${activity.title}",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold
                )
                if (activity.note.isNotBlank()) {
                    Text(
                        text = activity.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                if (!activity.lastErrorMessage.isNullOrBlank()) {
                    Text(
                        text = activity.lastErrorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFDC2626)
                    )
                }
            }
            ActivityStatusLabel(status = activity.status)
        }
    }
}
