package com.antidengue.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.antidengue.assistant.AntiDengueApp
import com.antidengue.assistant.data.model.AssistantRunState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Target-scoped AccessibilityService that ONLY inspects windows belonging to
 * the official Punjab Anti-Dengue package chosen by the user.
 *
 * Unrelated apps are ignored immediately. Unfamiliar screens stop automation
 * and request manual user review.
 */
class DengueAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var lastAutoFillTimestampMs: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        val app = application as? AntiDengueApp ?: return
        applyTargetPackageScope(app.repository.targetAppConfig.value.packageName)

        serviceScope.launch {
            app.repository.targetAppConfig.collectLatest { config ->
                applyTargetPackageScope(config.packageName)
            }
        }
    }

    private fun applyTargetPackageScope(targetPackage: String?) {
        val currentInfo = serviceInfo ?: AccessibilityServiceInfo()
        currentInfo.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
            AccessibilityEvent.TYPE_VIEW_CLICKED
        currentInfo.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        currentInfo.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
            AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
            AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        currentInfo.notificationTimeout = 150L
        currentInfo.packageNames = if (!targetPackage.isNullOrBlank()) {
            arrayOf(targetPackage)
        } else {
            // Restrict to own package when unconfigured so zero unrelated apps are observed.
            arrayOf(packageName)
        }
        runCatching {
            serviceInfo = currentInfo
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val app = application as? AntiDengueApp ?: return
        val targetPackage = app.repository.targetAppConfig.value.packageName
        if (targetPackage.isNullOrBlank()) {
            return
        }

        val eventPkg = event?.packageName?.toString()
        val root = rootInActiveWindow ?: return
        try {
            val rootPkg = root.packageName?.toString()
            // Strict guard: never inspect or interact with any unrelated app.
            if (rootPkg != targetPackage || (eventPkg != null && eventPkg != targetPackage)) {
                return
            }

            val descriptors = mutableListOf<AccessibleNodeDescriptor>()
            collectDescriptors(root, descriptors, depth = 0)

            if (app.repository.labelInspectorEnabled.value) {
                val safeLabels = descriptors
                    .filterNot { PitbScreenClassifier.isSensitiveCredentialNode(it) || it.isEditable }
                    .mapNotNull { d ->
                        val label = d.text.ifBlank { d.contentDescription }.trim()
                        val idPart = d.viewIdResourceName.substringAfterLast('/')
                        when {
                            label.isNotBlank() && idPart.isNotBlank() -> "$label ($idPart)"
                            label.isNotBlank() -> label
                            idPart.isNotBlank() -> "id:$idPart"
                            else -> null
                        }
                    }
                    .distinct()
                app.repository.updateInspectedLabels(safeLabels)
            }

            if (app.repository.runState.value != AssistantRunState.RUNNING) {
                return
            }

            val snapshot = PitbWindowSnapshot(
                packageName = rootPkg,
                nodes = descriptors
            )
            val screenType = PitbScreenClassifier.classify(snapshot)
            AutomationCoordinator.handleScreenClassification(app.repository, screenType)

            if (screenType == PitbScreenType.ACTIVITY_FORM) {
                maybeFillConfirmedRepeatedFields(app, root, descriptors)
            }
        } finally {
            root.recycle()
        }
    }

    private fun maybeFillConfirmedRepeatedFields(
        app: AntiDengueApp,
        root: AccessibilityNodeInfo,
        descriptors: List<AccessibleNodeDescriptor>
    ) {
        val now = System.currentTimeMillis()
        if (now - lastAutoFillTimestampMs < AUTO_FILL_COOLDOWN_MS) return

        val plans = AutomationCoordinator.matchTemplatesForEmptyFields(
            nodes = descriptors,
            templates = app.repository.fieldTemplates.value
        )
        if (plans.isEmpty()) return

        var filledAny = false
        for (plan in plans) {
            if (fillFirstMatchingEditableNode(root, plan)) {
                filledAny = true
            }
        }
        if (filledAny) {
            lastAutoFillTimestampMs = now
            app.repository.setAutomationStatusMessage(
                "Filled ${plans.size} user-confirmed repeated field(s). Please verify before saving."
            )
        }
    }

    private fun fillFirstMatchingEditableNode(
        node: AccessibilityNodeInfo,
        plan: PlannedFieldFill
    ): Boolean {
        val viewId = node.viewIdResourceName.orEmpty()
        val hintText = listOfNotNull(
            node.text?.toString(),
            node.contentDescription?.toString(),
            node.hintText?.toString(),
            viewId
        ).joinToString(" ").lowercase()

        val isPassword = node.isPassword
        val isMatch = node.isEditable && !isPassword && node.text.isNullOrBlank() && (
            (plan.targetViewId.isNotBlank() && viewId.equals(plan.targetViewId, ignoreCase = true)) ||
                (plan.labelHint.isNotBlank() && hintText.contains(plan.labelHint.lowercase()))
            )

        if (isMatch) {
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    plan.confirmedValue
                )
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (fillFirstMatchingEditableNode(child, plan)) {
                    return true
                }
            } finally {
                child.recycle()
            }
        }
        return false
    }

    private fun collectDescriptors(
        node: AccessibilityNodeInfo,
        out: MutableList<AccessibleNodeDescriptor>,
        depth: Int
    ) {
        if (depth > MAX_TREE_DEPTH || out.size >= MAX_NODES) return

        out.add(
            AccessibleNodeDescriptor(
                className = node.className?.toString().orEmpty(),
                viewIdResourceName = node.viewIdResourceName.orEmpty(),
                text = node.text?.toString().orEmpty(),
                contentDescription = node.contentDescription?.toString().orEmpty(),
                isClickable = node.isClickable,
                isEditable = node.isEditable,
                isPassword = node.isPassword
            )
        )

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collectDescriptors(child, out, depth + 1)
            } finally {
                child.recycle()
            }
        }
    }

    override fun onInterrupt() {
        val app = application as? AntiDengueApp ?: return
        if (app.repository.runState.value == AssistantRunState.RUNNING) {
            app.repository.setRunState(
                AssistantRunState.PAUSED,
                "Accessibility assistant interrupted by Android system."
            )
        }
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val MAX_TREE_DEPTH = 18
        private const val MAX_NODES = 120
        private const val AUTO_FILL_COOLDOWN_MS = 3500L
    }
}
