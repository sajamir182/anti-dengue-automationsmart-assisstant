package com.antidengue.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.antidengue.assistant.data.model.ConfirmedFieldTemplate
import com.antidengue.assistant.ui.theme.BorderHairline
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.viewmodel.AssistantViewModel

@Composable
fun FieldTemplatesScreen(vm: AssistantViewModel) {
    val templates by vm.fieldTemplates.collectAsState()
    val inspectorEnabled by vm.labelInspectorEnabled.collectAsState()
    val inspectedLabels by vm.lastInspectedLabels.collectAsState()

    var labelHint by remember { mutableStateOf("") }
    var viewIdHint by remember { mutableStateOf("") }
    var valueText by remember { mutableStateOf("") }
    var confirmedChecked by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "User-Confirmed Repeated Fields",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Only values you explicitly enter and confirm here can be assisted into empty non-sensitive form fields inside the official app. Inspection results and passwords are never invented or touched.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = labelHint,
                        onValueChange = { labelHint = it },
                        label = { Text("Field Label Hint (e.g., Union Council, Remarks)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = viewIdHint,
                        onValueChange = { viewIdHint = it },
                        label = { Text("Optional Android View ID Hint (from Inspector)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = valueText,
                        onValueChange = { valueText = it },
                        label = { Text("Confirmed Repeated Value") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = confirmedChecked,
                            onCheckedChange = { confirmedChecked = it }
                        )
                        Text(
                            text = "I confirm this repeated value is accurate for my daily entries.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(
                        onClick = {
                            if (labelHint.isNotBlank() && valueText.isNotBlank() && confirmedChecked) {
                                vm.saveFieldTemplate(
                                    ConfirmedFieldTemplate(
                                        fieldLabelHint = labelHint.trim(),
                                        targetViewIdHint = viewIdHint.trim(),
                                        confirmedValue = valueText.trim(),
                                        enabledForAutoFill = true,
                                        confirmedByUser = true
                                    )
                                )
                                labelHint = ""
                                viewIdHint = ""
                                valueText = ""
                                confirmedChecked = false
                            }
                        },
                        enabled = labelHint.isNotBlank() && valueText.isNotBlank() && confirmedChecked,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("Save Confirmed Field")
                    }
                }
            }
        }

        items(templates, key = { it.id }) { tpl ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(
                            text = tpl.fieldLabelHint,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Value: ${tpl.confirmedValue}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (tpl.targetViewIdHint.isNotBlank()) {
                            Text(
                                text = "ID hint: ${tpl.targetViewIdHint}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Switch(
                            checked = tpl.enabledForAutoFill,
                            onCheckedChange = { enabled ->
                                vm.saveFieldTemplate(tpl.copy(enabledForAutoFill = enabled))
                            }
                        )
                        TextButton(onClick = { vm.deleteFieldTemplate(tpl.id) }) {
                            Text("Remove", color = Color(0xFFDC2626))
                        }
                    }
                }
            }
        }

        // Calibration helper for phone-only use with PITB v9.4.0
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "PITB Screen Label Inspector",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Temporarily reads non-sensitive button labels and view IDs inside the selected PITB app to help you calibrate field hints on your phone.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = inspectorEnabled,
                            onCheckedChange = { vm.setLabelInspectorEnabled(it) }
                        )
                    }
                    if (inspectedLabels.isNotEmpty()) {
                        Text(
                            text = inspectedLabels.joinToString("\n"),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
