package com.antidengue.assistant.data.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.antidengue.assistant.data.model.ActivityStatus
import com.antidengue.assistant.data.model.BatchSessionRecord
import com.antidengue.assistant.data.model.ConfirmedFieldTemplate
import com.antidengue.assistant.data.model.DailyActivityRecord

class AssistantDatabaseHelper(context: Context) : SQLiteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE_ACTIVITIES (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date_key TEXT NOT NULL,
                activity_number INTEGER NOT NULL,
                title TEXT NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL,
                before_photo_at INTEGER,
                after_timer_ends_wall INTEGER,
                after_photo_at INTEGER,
                user_reviewed INTEGER NOT NULL DEFAULT 0,
                saved_verified_at INTEGER,
                submitted_verified_at INTEGER,
                last_error TEXT,
                UNIQUE(date_key, activity_number)
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE $TABLE_FIELD_TEMPLATES (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                field_label_hint TEXT NOT NULL,
                target_view_id_hint TEXT NOT NULL DEFAULT '',
                confirmed_value TEXT NOT NULL,
                enabled_for_autofill INTEGER NOT NULL DEFAULT 0,
                confirmed_by_user INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE $TABLE_BATCH_SESSIONS (
                date_key TEXT PRIMARY KEY,
                submission_locked INTEGER NOT NULL DEFAULT 0,
                submitted_batch_at INTEGER,
                official_confirmation_note TEXT
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Future schema migrations go here without dropping user data.
    }

    fun ensureDailyActivities(dateKey: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val countCursor = db.rawQuery(
                "SELECT COUNT(*) FROM $TABLE_ACTIVITIES WHERE date_key = ?",
                arrayOf(dateKey)
            )
            val existingCount = countCursor.use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (existingCount == 0) {
                for (num in 1..20) {
                    val values = ContentValues().apply {
                        put("date_key", dateKey)
                        put("activity_number", num)
                        put("title", "Daily Activity #$num")
                        put("note", "")
                        put("status", ActivityStatus.PENDING.name)
                        put("user_reviewed", 0)
                    }
                    db.insertWithOnConflict(
                        TABLE_ACTIVITIES,
                        null,
                        values,
                        SQLiteDatabase.CONFLICT_IGNORE
                    )
                }
            }

            val batchValues = ContentValues().apply {
                put("date_key", dateKey)
                put("submission_locked", 0)
            }
            db.insertWithOnConflict(
                TABLE_BATCH_SESSIONS,
                null,
                batchValues,
                SQLiteDatabase.CONFLICT_IGNORE
            )

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun getActivitiesForDate(dateKey: String): List<DailyActivityRecord> {
        ensureDailyActivities(dateKey)
        val result = mutableListOf<DailyActivityRecord>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ACTIVITIES,
            null,
            "date_key = ?",
            arrayOf(dateKey),
            null,
            null,
            "activity_number ASC"
        )
        cursor.use {
            while (it.moveToNext()) {
                val statusName = it.getString(it.getColumnIndexOrThrow("status"))
                val status = runCatching { ActivityStatus.valueOf(statusName) }
                    .getOrDefault(ActivityStatus.PENDING)
                result.add(
                    DailyActivityRecord(
                        id = it.getLong(it.getColumnIndexOrThrow("id")),
                        dateKey = it.getString(it.getColumnIndexOrThrow("date_key")),
                        activityNumber = it.getInt(it.getColumnIndexOrThrow("activity_number")),
                        title = it.getString(it.getColumnIndexOrThrow("title")),
                        note = it.getString(it.getColumnIndexOrThrow("note")),
                        status = status,
                        beforePhotoCapturedAtMs = it.getNullableLong("before_photo_at"),
                        afterTimerEndsWallMs = it.getNullableLong("after_timer_ends_wall"),
                        afterPhotoCapturedAtMs = it.getNullableLong("after_photo_at"),
                        userReviewedBeforeSave = it.getInt(it.getColumnIndexOrThrow("user_reviewed")) == 1,
                        savedVerifiedAtMs = it.getNullableLong("saved_verified_at"),
                        submittedVerifiedAtMs = it.getNullableLong("submitted_verified_at"),
                        lastErrorMessage = it.getNullableString("last_error")
                    )
                )
            }
        }
        return result
    }

    fun updateActivity(record: DailyActivityRecord) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("title", record.title)
            put("note", record.note)
            put("status", record.status.name)
            putNullableLong("before_photo_at", record.beforePhotoCapturedAtMs)
            putNullableLong("after_timer_ends_wall", record.afterTimerEndsWallMs)
            putNullableLong("after_photo_at", record.afterPhotoCapturedAtMs)
            put("user_reviewed", if (record.userReviewedBeforeSave) 1 else 0)
            putNullableLong("saved_verified_at", record.savedVerifiedAtMs)
            putNullableLong("submitted_verified_at", record.submittedVerifiedAtMs)
            putNullableString("last_error", record.lastErrorMessage)
        }
        db.update(
            TABLE_ACTIVITIES,
            values,
            "date_key = ? AND activity_number = ?",
            arrayOf(record.dateKey, record.activityNumber.toString())
        )
    }

    fun getBatchSession(dateKey: String): BatchSessionRecord {
        ensureDailyActivities(dateKey)
        val db = readableDatabase
        val cursor = db.query(
            TABLE_BATCH_SESSIONS,
            null,
            "date_key = ?",
            arrayOf(dateKey),
            null,
            null,
            null
        )
        cursor.use {
            if (it.moveToFirst()) {
                return BatchSessionRecord(
                    dateKey = it.getString(it.getColumnIndexOrThrow("date_key")),
                    submissionLocked = it.getInt(it.getColumnIndexOrThrow("submission_locked")) == 1,
                    submittedBatchAtMs = it.getNullableLong("submitted_batch_at"),
                    officialConfirmationNote = it.getNullableString("official_confirmation_note")
                )
            }
        }
        return BatchSessionRecord(dateKey = dateKey)
    }

    fun updateBatchSession(session: BatchSessionRecord) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("submission_locked", if (session.submissionLocked) 1 else 0)
            putNullableLong("submitted_batch_at", session.submittedBatchAtMs)
            putNullableString("official_confirmation_note", session.officialConfirmationNote)
        }
        db.update(
            TABLE_BATCH_SESSIONS,
            values,
            "date_key = ?",
            arrayOf(session.dateKey)
        )
    }

    fun resetDaySession(dateKey: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete(TABLE_ACTIVITIES, "date_key = ?", arrayOf(dateKey))
            db.delete(TABLE_BATCH_SESSIONS, "date_key = ?", arrayOf(dateKey))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        ensureDailyActivities(dateKey)
    }

    fun getFieldTemplates(): List<ConfirmedFieldTemplate> {
        val result = mutableListOf<ConfirmedFieldTemplate>()
        val cursor = readableDatabase.query(
            TABLE_FIELD_TEMPLATES,
            null,
            null,
            null,
            null,
            null,
            "id ASC"
        )
        cursor.use {
            while (it.moveToNext()) {
                result.add(
                    ConfirmedFieldTemplate(
                        id = it.getLong(it.getColumnIndexOrThrow("id")),
                        fieldLabelHint = it.getString(it.getColumnIndexOrThrow("field_label_hint")),
                        targetViewIdHint = it.getString(it.getColumnIndexOrThrow("target_view_id_hint")),
                        confirmedValue = it.getString(it.getColumnIndexOrThrow("confirmed_value")),
                        enabledForAutoFill = it.getInt(it.getColumnIndexOrThrow("enabled_for_autofill")) == 1,
                        confirmedByUser = it.getInt(it.getColumnIndexOrThrow("confirmed_by_user")) == 1,
                        updatedAtMs = it.getLong(it.getColumnIndexOrThrow("updated_at"))
                    )
                )
            }
        }
        return result
    }

    fun upsertFieldTemplate(template: ConfirmedFieldTemplate): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("field_label_hint", template.fieldLabelHint)
            put("target_view_id_hint", template.targetViewIdHint)
            put("confirmed_value", template.confirmedValue)
            put("enabled_for_autofill", if (template.enabledForAutoFill) 1 else 0)
            put("confirmed_by_user", if (template.confirmedByUser) 1 else 0)
            put("updated_at", template.updatedAtMs)
        }
        return if (template.id > 0L) {
            db.update(TABLE_FIELD_TEMPLATES, values, "id = ?", arrayOf(template.id.toString()))
            template.id
        } else {
            db.insert(TABLE_FIELD_TEMPLATES, null, values)
        }
    }

    fun deleteFieldTemplate(id: Long) {
        writableDatabase.delete(TABLE_FIELD_TEMPLATES, "id = ?", arrayOf(id.toString()))
    }

    private fun android.database.Cursor.getNullableLong(column: String): Long? {
        val idx = getColumnIndexOrThrow(column)
        return if (isNull(idx)) null else getLong(idx)
    }

    private fun android.database.Cursor.getNullableString(column: String): String? {
        val idx = getColumnIndexOrThrow(column)
        return if (isNull(idx)) null else getString(idx)
    }

    private fun ContentValues.putNullableLong(key: String, value: Long?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun ContentValues.putNullableString(key: String, value: String?) {
        if (value == null) putNull(key) else put(key, value)
    }

    companion object {
        private const val DATABASE_NAME = "anti_dengue_assistant.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_ACTIVITIES = "daily_activities"
        private const val TABLE_FIELD_TEMPLATES = "field_templates"
        private const val TABLE_BATCH_SESSIONS = "batch_sessions"
    }
}
