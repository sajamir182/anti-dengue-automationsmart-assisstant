package com.antidengue.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF0F5132)
val PrimaryGreenLight = Color(0xFFD1E7DD)
val SecondarySlate = Color(0xFF334155)
val SurfaceWhite = Color(0xFFFFFFFF)
val BackgroundSlate = Color(0xFFF8FAFC)
val BorderHairline = Color(0xFFE2E8F0)
val WarningAmber = Color(0xFFB45309)
val WarningAmberBg = Color(0xFFFEF3C7)
val DangerCrimson = Color(0xFFDC2626)
val DangerCrimsonBg = Color(0xFFFEE2E2)
val InfoBlue = Color(0xFF1D4ED8)
val InfoBlueBg = Color(0xFFDBEAFE)

private val AppColorScheme = lightColorScheme(
    primary = PrimaryGreen,
    onPrimary = Color.White,
    primaryContainer = PrimaryGreenLight,
    onPrimaryContainer = PrimaryGreen,
    secondary = SecondarySlate,
    onSecondary = Color.White,
    background = BackgroundSlate,
    onBackground = Color(0xFF0F172A),
    surface = SurfaceWhite,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    error = DangerCrimson,
    onError = Color.White,
    outline = BorderHairline
)

@Composable
fun AntiDengueAssistantTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColorScheme,
        content = content
    )
}
