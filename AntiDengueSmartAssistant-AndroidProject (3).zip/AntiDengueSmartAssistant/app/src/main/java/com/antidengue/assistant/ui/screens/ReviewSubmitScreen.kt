package com.antidengue.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.antidengue.assistant.data.model.ActivityStatus
import com.antidengue.assistant.ui.components.NetworkWarningBanner
import com.antidengue.assistant.ui.theme.BorderHairline
import com.antidengue.assistant.ui.theme.DangerCrimson
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.theme.PrimaryGreenLight
import com.antidengue.assistant.ui.theme.WarningAmber
import com.antidengue.assistant.ui.theme.WarningAmberBg
import com.antidengue.assistant.ui.viewmodel.AssistantViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReviewSubmitScreen(
    vm: AssistantViewModel,
    onBackToDashboard: () -> Unit
) {
    val summary by vm.summary.collectAsState()
    val activities by vm.activities.collectAsState()
    val batchSession by vm.batchSession.collectAsState()
    val networkStatus by vm.networkStatus.collectAsState()

    var explicitConfirmChecked by remember { mutableStateOf(false) }
    var confirmationNote by remember { mutableStateOf("Official app confirmed Submit All success") }

    val savedList = activities.filter { it.status == ActivityStatus.SAVED }
    val incompleteList = activities.filter { !it.isCompletedForProgress }
    val scroll = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scroll)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Save All → Final Review & Submit Once",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        NetworkWarningBanner(networkStatus = networkStatus)

        if (batchSession.submissionLocked && batchSession.submittedBatchAtMs != null) {
            val formattedTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                .format(Date(batchSession.submittedBatchAtMs ?: 0L))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PrimaryGreenLight),
                border = BorderStroke(1.dp, PrimaryGreen.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Batch Already Submitted (Duplicate Guard Active)",
                        color = PrimaryGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Confirmed at $formattedTime · ${batchSession.officialConfirmationNote ?: ""}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Batch Summary",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Saved & Ready to Submit: ${savedList.size} / 20",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryGreen
                )
                Text(
                    text = "Already Submitted: ${summary.submittedCount} / 20",
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Pending / Incomplete: ${incompleteList.size}",
                    fontFamily = FontFamily.Monospace,
                    color = if (incompleteList.isNotEmpty()) WarningAmber else Color.Unspecified
                )
                Text(
                    text = "Connectivity: ${networkStatus.transportLabel}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        if (incompleteList.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = WarningAmberBg),
                border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Warning: ${incompleteList.size} activities are not yet saved",
                        color = WarningAmber,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Incomplete numbers: ${incompleteList.joinToString(", ") { "#${it.activityNumber}" }}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderHairline),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Explicit Confirmation Required",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "1. Open the official Punjab Anti-Dengue app and trigger Submit All.\n2. Wait until the official app confirms upload success.\n3. Never confirm success if a network error or timeout occurred.",
                    style = MaterialTheme.typography.bodySmall
                )

                OutlinedButton(
                    onClick = { vm.openOfficialPitbApp() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Official PITB App to Submit All")
                }

                OutlinedTextField(
                    value = confirmationNote,
                    onValueChange = { confirmationNote = it },
                    label = { Text("Official App Result Note") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = explicitConfirmChecked,
                        onCheckedChange = { explicitConfirmChecked = it }
                    )
                    Text(
                        text = "I confirm the official app displayed a genuine submission success confirmation for these saved records.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                val canConfirmBatch = !batchSession.submissionLocked &&
                    savedList.isNotEmpty() &&
                    networkStatus.isConnected &&
                    explicitConfirmChecked

                Button(
                    onClick = { vm.confirmBatchSubmitAll(confirmationNote) },
                    enabled = canConfirmBatch,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                ) {
                    Text("Confirm Batch Submitted (${savedList.size} Activities)")
                }

                if (!networkStatus.isConnected) {
                    Text(
                        text = "Submission confirmation is disabled while offline.",
                        color = DangerCrimson,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        OutlinedButton(
            onClick = onBackToDashboard,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Return to Dashboard")
        }
    }
}
