package com.antidengue.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.antidengue.assistant.ui.screens.ActivityDetailScreen
import com.antidengue.assistant.ui.screens.DashboardScreen
import com.antidengue.assistant.ui.screens.FieldTemplatesScreen
import com.antidengue.assistant.ui.screens.ReviewSubmitScreen
import com.antidengue.assistant.ui.screens.SetupGuideScreen
import com.antidengue.assistant.ui.theme.AntiDengueAssistantTheme
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.viewmodel.AssistantViewModel

private enum class AssistantTab(val label: String) {
    DASHBOARD("Dashboard"),
    TEMPLATES("Fields"),
    REVIEW_SUBMIT("Submit All"),
    SETUP("Setup")
}

class MainActivity : ComponentActivity() {

    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Notification channel status is checked safely by service */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            AntiDengueAssistantTheme {
                val vm: AssistantViewModel = viewModel()
                AssistantRootScreen(vm)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val app = application as AntiDengueApp
        app.connectivityMonitor.refreshNow()
        app.repository.refreshAll()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AssistantRootScreen(vm: AssistantViewModel) {
    var currentTab by remember { mutableStateOf(AssistantTab.DASHBOARD) }
    var selectedActivityNumber by remember { mutableStateOf<Int?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val bannerMessage by vm.uiFeedbackBanner.collectAsState()
    val unfamiliarPrompt by vm.unfamiliarScreenPrompt.collectAsState()

    LaunchedEffect(bannerMessage) {
        val msg = bannerMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            vm.clearFeedbackBanner()
        }
    }

    if (unfamiliarPrompt != null) {
        AlertDialog(
            onDismissRequest = { vm.dismissUnfamiliarPrompt() },
            title = { Text("Manual Assistance Required") },
            text = { Text(unfamiliarPrompt ?: "") },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.dismissUnfamiliarPrompt()
                        vm.startOrResumeAssistant()
                    }
                ) {
                    Text("Resume Assistant")
                }
            },
            dismissButton = {
                TextButton(onClick = { vm.dismissUnfamiliarPrompt() }) {
                    Text("Stay Paused")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (selectedActivityNumber != null) {
                            "Activity #$selectedActivityNumber Assistant"
                        } else {
                            "Anti-Dengue Smart Assistant"
                        },
                        color = Color.White
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (selectedActivityNumber == null) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentTab == AssistantTab.DASHBOARD,
                        onClick = { currentTab = AssistantTab.DASHBOARD },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Dashboard") },
                        label = { Text("Dashboard") }
                    )
                    NavigationBarItem(
                        selected = currentTab == AssistantTab.TEMPLATES,
                        onClick = { currentTab = AssistantTab.TEMPLATES },
                        icon = { Icon(Icons.Default.EditNote, contentDescription = "Fields") },
                        label = { Text("Fields") }
                    )
                    NavigationBarItem(
                        selected = currentTab == AssistantTab.REVIEW_SUBMIT,
                        onClick = { currentTab = AssistantTab.REVIEW_SUBMIT },
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Submit All") },
                        label = { Text("Submit All") }
                    )
                    NavigationBarItem(
                        selected = currentTab == AssistantTab.SETUP,
                        onClick = {
                            vm.refreshSystemStatus()
                            vm.scanInstalledApps()
                            currentTab = AssistantTab.SETUP
                        },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Setup") },
                        label = { Text("Setup") }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val detailNumber = selectedActivityNumber
            if (detailNumber != null) {
                ActivityDetailScreen(
                    vm = vm,
                    activityNumber = detailNumber,
                    onBack = { selectedActivityNumber = null }
                )
            } else {
                when (currentTab) {
                    AssistantTab.DASHBOARD -> DashboardScreen(
                        vm = vm,
                        onOpenActivity = { num ->
                            vm.selectActivity(num)
                            selectedActivityNumber = num
                        },
                        onGoToReviewSubmit = { currentTab = AssistantTab.REVIEW_SUBMIT },
                        onGoToSetup = {
                            vm.refreshSystemStatus()
                            vm.scanInstalledApps()
                            currentTab = AssistantTab.SETUP
                        }
                    )
                    AssistantTab.TEMPLATES -> FieldTemplatesScreen(vm = vm)
                    AssistantTab.REVIEW_SUBMIT -> ReviewSubmitScreen(
                        vm = vm,
                        onBackToDashboard = { currentTab = AssistantTab.DASHBOARD }
                    )
                    AssistantTab.SETUP -> SetupGuideScreen(vm = vm)
                }
            }
        }
    }
}
