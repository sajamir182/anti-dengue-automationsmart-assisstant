package com.antidengue.assistant.data.model

enum class SubmissionMode(val displayName: String, val description: String) {
    SAVE_ALL(
        displayName = "Save All → Submit Once",
        description = "Complete all 20 activities, save each locally inside the official app, review the full batch, then submit once."
    ),
    IMMEDIATE_SUBMIT(
        displayName = "Immediate Individual Submit",
        description = "Complete, review, and submit each activity one by one inside the official app."
    )
}

enum class AssistantRunState(val label: String) {
    IDLE("Ready"),
    RUNNING("Active"),
    PAUSED("Paused"),
    PAUSED_UNFAMILIAR_SCREEN("Paused — Manual Help Needed"),
    COMPLETED_BATCH("All 20 Submitted")
}

enum class ActivityStatus(val label: String, val isTerminalForSaveAll: Boolean) {
    PENDING("Pending", false),
    IN_PROGRESS("In Progress", false),
    WAITING_AFTER_TIMER("2-Min Timer Running", false),
    READY_FOR_AFTER_PHOTO("Ready for After Photo", false),
    READY_TO_REVIEW("Ready to Review", false),
    SAVED("Saved (Pending Submit)", true),
    SUBMITTED("Submitted (Confirmed)", true),
    NEEDS_ATTENTION("Needs Attention", false)
}

data class DailyActivityRecord(
    val id: Long = 0L,
    val dateKey: String,
    val activityNumber: Int, // 1..20
    val title: String,
    val note: String = "",
    val status: ActivityStatus = ActivityStatus.PENDING,
    val beforePhotoCapturedAtMs: Long? = null,
    val afterTimerEndsWallMs: Long? = null,
    val afterPhotoCapturedAtMs: Long? = null,
    val userReviewedBeforeSave: Boolean = false,
    val savedVerifiedAtMs: Long? = null,
    val submittedVerifiedAtMs: Long? = null,
    val lastErrorMessage: String? = null
) {
    val isCompletedForProgress: Boolean
        get() = status == ActivityStatus.SAVED || status == ActivityStatus.SUBMITTED
}

data class DashboardSummary(
    val totalCount: Int = 20,
    val completedCount: Int = 0,
    val savedCount: Int = 0,
    val submittedCount: Int = 0,
    val pendingCount: Int = 20,
    val progressPercent: Int = 0
)

data class BatchSessionRecord(
    val dateKey: String,
    val submissionLocked: Boolean = false,
    val submittedBatchAtMs: Long? = null,
    val officialConfirmationNote: String? = null
)

data class TargetAppConfig(
    val packageName: String? = null,
    val appLabel: String? = null,
    val versionName: String? = null
)

data class TimerUiState(
    val isRunning: Boolean = false,
    val activityNumber: Int? = null,
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 120,
    val isFinishedReadyForAfterPhoto: Boolean = false
)
