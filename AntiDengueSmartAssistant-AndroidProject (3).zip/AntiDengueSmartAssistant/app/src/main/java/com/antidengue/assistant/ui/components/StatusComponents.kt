package com.antidengue.assistant.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.antidengue.assistant.data.model.ActivityStatus
import com.antidengue.assistant.data.model.TimerUiState
import com.antidengue.assistant.network.NetworkStatus
import com.antidengue.assistant.ui.theme.BorderHairline
import com.antidengue.assistant.ui.theme.DangerCrimson
import com.antidengue.assistant.ui.theme.DangerCrimsonBg
import com.antidengue.assistant.ui.theme.InfoBlue
import com.antidengue.assistant.ui.theme.InfoBlueBg
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.theme.PrimaryGreenLight
import com.antidengue.assistant.ui.theme.WarningAmber
import com.antidengue.assistant.ui.theme.WarningAmberBg

@Composable
fun NetworkWarningBanner(networkStatus: NetworkStatus) {
    if (!networkStatus.isConnected) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DangerCrimsonBg),
            border = BorderStroke(1.dp, DangerCrimson.copy(alpha = 0.35f)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Offline Warning: ${networkStatus.transportLabel}",
                    color = DangerCrimson,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "You can continue preparing local saves if the official app supports offline drafts, but do not attempt Submit All until internet connectivity is restored.",
                    color = Color(0xFF7F1D1D),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun ActivePhotoTimerBanner(
    timerState: TimerUiState,
    onOpenOfficialApp: () -> Unit,
    onOpenActivity: (Int) -> Unit
) {
    val actNum = timerState.activityNumber ?: return
    if (!timerState.isRunning && !timerState.isFinishedReadyForAfterPhoto) return

    val bg = if (timerState.isFinishedReadyForAfterPhoto) PrimaryGreenLight else WarningAmberBg
    val fg = if (timerState.isFinishedReadyForAfterPhoto) PrimaryGreen else WarningAmber
    val mins = timerState.remainingSeconds / 60
    val secs = timerState.remainingSeconds % 60
    val timeText = String.format("%02d:%02d", mins, secs)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, fg.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = if (timerState.isFinishedReadyForAfterPhoto) {
                        "Activity #$actNum · 2:00 Complete!"
                    } else {
                        "Activity #$actNum · Wait $timeText"
                    },
                    color = fg,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = if (timerState.isFinishedReadyForAfterPhoto) {
                        "Capture the genuine After photo in the official app now."
                    } else {
                        "You may continue other work; audible alert fires at 00:00."
                    },
                    color = Color(0xFF1E293B),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = { onOpenActivity(actNum) },
                    colors = ButtonDefaults.buttonColors(containerColor = fg)
                ) {
                    Text("Details")
                }
                if (timerState.isFinishedReadyForAfterPhoto) {
                    Button(
                        onClick = onOpenOfficialApp,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("PITB App")
                    }
                }
            }
        }
    }
}

@Composable
fun ActivityStatusLabel(status: ActivityStatus) {
    val (bg, fg) = when (status) {
        ActivityStatus.PENDING -> Color(0xFFF1F5F9) to Color(0xFF475569)
        ActivityStatus.IN_PROGRESS -> InfoBlueBg to InfoBlue
        ActivityStatus.WAITING_AFTER_TIMER -> WarningAmberBg to WarningAmber
        ActivityStatus.READY_FOR_AFTER_PHOTO -> PrimaryGreenLight to PrimaryGreen
        ActivityStatus.READY_TO_REVIEW -> InfoBlueBg to InfoBlue
        ActivityStatus.SAVED -> PrimaryGreenLight to PrimaryGreen
        ActivityStatus.SUBMITTED -> Color(0xFF065F46) to Color.White
        ActivityStatus.NEEDS_ATTENTION -> DangerCrimsonBg to DangerCrimson
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, BorderHairline)
    ) {
        Text(
            text = status.label,
            color = fg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
