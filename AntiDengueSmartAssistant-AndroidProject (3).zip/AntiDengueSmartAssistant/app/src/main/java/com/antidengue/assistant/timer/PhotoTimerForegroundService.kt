package com.antidengue.assistant.timer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.antidengue.assistant.AntiDengueApp
import com.antidengue.assistant.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps the genuine 2-minute interval between Before and After photos reliable
 * even when the user switches to other work or locks the screen on Oppo ColorOS.
 * Uses Android's monotonic elapsedRealtime clock and never alters device time.
 */
class PhotoTimerForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var countdownJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_TIMER -> {
                val activityNumber = intent.getIntExtra(EXTRA_ACTIVITY_NUMBER, 1)
                val durationSec = intent.getIntExtra(EXTRA_DURATION_SECONDS, 120)
                startCountdown(activityNumber, durationSec)
            }
            ACTION_STOP_TIMER -> {
                countdownJob?.cancel()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCountdown(activityNumber: Int, durationSec: Int) {
        countdownJob?.cancel()
        val app = application as AntiDengueApp
        val targetElapsedMs = SystemClock.elapsedRealtime() + durationSec * 1000L

        startForeground(
            NOTIFICATION_ID_PROGRESS,
            buildProgressNotification(activityNumber, durationSec)
        )

        countdownJob = serviceScope.launch {
            while (isActive) {
                val remainingMs = targetElapsedMs - SystemClock.elapsedRealtime()
                val remainingSec = ((remainingMs + 999L) / 1000L).toInt().coerceAtLeast(0)
                app.repository.updateTimerTick(activityNumber, remainingSec)

                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (remainingSec <= 0) {
                    app.repository.markTimerCompleted(activityNumber)
                    nm.notify(
                        NOTIFICATION_ID_COMPLETE,
                        buildCompletedNotification(activityNumber)
                    )
                    playAudibleAlert()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    break
                } else {
                    nm.notify(
                        NOTIFICATION_ID_PROGRESS,
                        buildProgressNotification(activityNumber, remainingSec)
                    )
                    delay(1000L)
                }
            }
        }
    }

    private fun playAudibleAlert() {
        runCatching {
            val alertUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val ringtone = RingtoneManager.getRingtone(applicationContext, alertUri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ringtone?.play()
        }
    }

    private fun buildProgressNotification(activityNumber: Int, remainingSec: Int): Notification {
        val mins = remainingSec / 60
        val secs = remainingSec % 60
        val formatted = String.format("%02d:%02d", mins, secs)

        return NotificationCompat.Builder(this, CHANNEL_PROGRESS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Activity #$activityNumber · 2-Minute Photo Timer")
            .setContentText("$formatted remaining before capturing genuine After photo")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(createMainActivityPendingIntent())
            .build()
    }

    private fun buildCompletedNotification(activityNumber: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_COMPLETE)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("2 Minutes Complete — Activity #$activityNumber")
            .setContentText("Return to the official Anti-Dengue app and capture the genuine After photo.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(createMainActivityPendingIntent())
            .build()
    }

    private fun createMainActivityPendingIntent(): PendingIntent {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val immutableFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_IMMUTABLE
        } else {
            0
        }
        return PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag
        )
    }

    private fun ensureNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val progressChannel = NotificationChannel(
                CHANNEL_PROGRESS,
                "2-Minute Photo Countdown",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays live remaining seconds while waiting for the After photo."
                setSound(null, null)
            }

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val completeChannel = NotificationChannel(
                CHANNEL_COMPLETE,
                "After Photo Ready Alert",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Audible alert when the 2-minute interval has elapsed."
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 350, 200, 350)
                setSound(soundUri, audioAttrs)
            }

            nm.createNotificationChannel(progressChannel)
            nm.createNotificationChannel(completeChannel)
        }
    }

    override fun onDestroy() {
        countdownJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val ACTION_START_TIMER = "com.antidengue.assistant.START_TIMER"
        private const val ACTION_STOP_TIMER = "com.antidengue.assistant.STOP_TIMER"
        private const val EXTRA_ACTIVITY_NUMBER = "extra_activity_number"
        private const val EXTRA_DURATION_SECONDS = "extra_duration_seconds"
        private const val CHANNEL_PROGRESS = "photo_timer_progress"
        private const val CHANNEL_COMPLETE = "photo_timer_done"
        private const val NOTIFICATION_ID_PROGRESS = 1001
        private const val NOTIFICATION_ID_COMPLETE = 1002

        fun start(context: Context, activityNumber: Int, durationSeconds: Int = 120) {
            val intent = Intent(context, PhotoTimerForegroundService::class.java).apply {
                action = ACTION_START_TIMER
                putExtra(EXTRA_ACTIVITY_NUMBER, activityNumber)
                putExtra(EXTRA_DURATION_SECONDS, durationSeconds)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, PhotoTimerForegroundService::class.java).apply {
                action = ACTION_STOP_TIMER
            }
            context.startService(intent)
        }
    }
}
