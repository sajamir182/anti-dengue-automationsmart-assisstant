package com.antidengue.assistant.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.antidengue.assistant.data.db.AssistantDatabaseHelper
import com.antidengue.assistant.data.model.ActivityStatus
import com.antidengue.assistant.data.model.AssistantRunState
import com.antidengue.assistant.data.model.BatchSessionRecord
import com.antidengue.assistant.data.model.ConfirmedFieldTemplate
import com.antidengue.assistant.data.model.DailyActivityRecord
import com.antidengue.assistant.data.model.DashboardSummary
import com.antidengue.assistant.data.model.SubmissionMode
import com.antidengue.assistant.data.model.TargetAppConfig
import com.antidengue.assistant.data.model.TimerUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AssistantRepository(context: Context) {

    private val appContext = context.applicationContext
    private val dbHelper = AssistantDatabaseHelper(appContext)
    private val prefs: SharedPreferences = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _todayDateKey = MutableStateFlow(currentDateKey())
    val todayDateKey: StateFlow<String> = _todayDateKey.asStateFlow()

    private val _activities = MutableStateFlow<List<DailyActivityRecord>>(emptyList())
    val activities: StateFlow<List<DailyActivityRecord>> = _activities.asStateFlow()

    private val _summary = MutableStateFlow(DashboardSummary())
    val summary: StateFlow<DashboardSummary> = _summary.asStateFlow()

    private val _runState = MutableStateFlow(loadRunState())
    val runState: StateFlow<AssistantRunState> = _runState.asStateFlow()

    private val _submissionMode = MutableStateFlow(loadSubmissionMode())
    val submissionMode: StateFlow<SubmissionMode> = _submissionMode.asStateFlow()

    private val _targetAppConfig = MutableStateFlow(loadTargetAppConfig())
    val targetAppConfig: StateFlow<TargetAppConfig> = _targetAppConfig.asStateFlow()

    private val _fieldTemplates = MutableStateFlow<List<ConfirmedFieldTemplate>>(emptyList())
    val fieldTemplates: StateFlow<List<ConfirmedFieldTemplate>> = _fieldTemplates.asStateFlow()

    private val _batchSession = MutableStateFlow(BatchSessionRecord(currentDateKey()))
    val batchSession: StateFlow<BatchSessionRecord> = _batchSession.asStateFlow()

    private val _timerState = MutableStateFlow(TimerUiState())
    val timerState: StateFlow<TimerUiState> = _timerState.asStateFlow()

    private val _activeActivityNumber = MutableStateFlow(loadActiveActivityNumber())
    val activeActivityNumber: StateFlow<Int> = _activeActivityNumber.asStateFlow()

    private val _automationStatusMessage = MutableStateFlow(
        prefs.getString(KEY_AUTOMATION_MSG, "Assistant ready. Select the official PITB app before starting.")
            ?: "Assistant ready."
    )
    val automationStatusMessage: StateFlow<String> = _automationStatusMessage.asStateFlow()

    private val _unfamiliarScreenPrompt = MutableStateFlow<String?>(null)
    val unfamiliarScreenPrompt: StateFlow<String?> = _unfamiliarScreenPrompt.asStateFlow()

    private val _lastInspectedLabels = MutableStateFlow<List<String>>(emptyList())
    val lastInspectedLabels: StateFlow<List<String>> = _lastInspectedLabels.asStateFlow()

    private val _labelInspectorEnabled = MutableStateFlow(prefs.getBoolean(KEY_INSPECTOR_ENABLED, false))
    val labelInspectorEnabled: StateFlow<Boolean> = _labelInspectorEnabled.asStateFlow()

    init {
        refreshAll()
    }

    @Synchronized
    fun refreshAll() {
        val dateKey = currentDateKey()
        _todayDateKey.value = dateKey
        val list = dbHelper.getActivitiesForDate(dateKey)
        _activities.value = list
        _summary.value = computeSummary(list)
        _fieldTemplates.value = dbHelper.getFieldTemplates()
        _batchSession.value = dbHelper.getBatchSession(dateKey)
        reconcileActiveTimerFromStorage(list)
    }

    private fun reconcileActiveTimerFromStorage(list: List<DailyActivityRecord>) {
        val now = System.currentTimeMillis()
        val waiting = list.firstOrNull { it.status == ActivityStatus.WAITING_AFTER_TIMER }
        if (waiting != null && waiting.afterTimerEndsWallMs != null) {
            val remainingSec = ((waiting.afterTimerEndsWallMs - now) / 1000L).toInt()
            if (remainingSec > 0) {
                _timerState.value = TimerUiState(
                    isRunning = true,
                    activityNumber = waiting.activityNumber,
                    remainingSeconds = remainingSec,
                    totalSeconds = PHOTO_WAIT_SECONDS,
                    isFinishedReadyForAfterPhoto = false
                )
            } else {
                // Timer elapsed while app was closed: promote activity cleanly
                val updated = waiting.copy(status = ActivityStatus.READY_FOR_AFTER_PHOTO)
                dbHelper.updateActivity(updated)
                val reloaded = dbHelper.getActivitiesForDate(waiting.dateKey)
                _activities.value = reloaded
                _summary.value = computeSummary(reloaded)
                _timerState.value = TimerUiState(
                    isRunning = false,
                    activityNumber = waiting.activityNumber,
                    remainingSeconds = 0,
                    totalSeconds = PHOTO_WAIT_SECONDS,
                    isFinishedReadyForAfterPhoto = true
                )
            }
        }
    }

    fun setRunState(newState: AssistantRunState, message: String? = null) {
        _runState.value = newState
        prefs.edit().putString(KEY_RUN_STATE, newState.name).apply()
        if (message != null) {
            setAutomationStatusMessage(message)
        }
    }

    fun setSubmissionMode(mode: SubmissionMode) {
        _submissionMode.value = mode
        prefs.edit().putString(KEY_SUBMISSION_MODE, mode.name).apply()
    }

    fun setTargetApp(config: TargetAppConfig) {
        _targetAppConfig.value = config
        prefs.edit()
            .putString(KEY_TARGET_PKG, config.packageName)
            .putString(KEY_TARGET_LABEL, config.appLabel)
            .putString(KEY_TARGET_VERSION, config.versionName)
            .apply()
    }

    fun setActiveActivityNumber(number: Int) {
        val clamped = number.coerceIn(1, 20)
        _activeActivityNumber.value = clamped
        prefs.edit().putInt(KEY_ACTIVE_ACTIVITY, clamped).apply()
    }

    fun setAutomationStatusMessage(msg: String) {
        _automationStatusMessage.value = msg
        prefs.edit().putString(KEY_AUTOMATION_MSG, msg).apply()
    }

    fun setUnfamiliarScreenPrompt(prompt: String?) {
        _unfamiliarScreenPrompt.value = prompt
    }

    fun setLabelInspectorEnabled(enabled: Boolean) {
        _labelInspectorEnabled.value = enabled
        prefs.edit().putBoolean(KEY_INSPECTOR_ENABLED, enabled).apply()
    }

    fun updateInspectedLabels(labels: List<String>) {
        _lastInspectedLabels.value = labels.take(25)
    }

    @Synchronized
    fun startOrResumeNextPendingActivity(): DailyActivityRecord? {
        refreshAll()
        val list = _activities.value
        val active = list.firstOrNull { it.activityNumber == _activeActivityNumber.value }
        val next = if (active != null && !active.isCompletedForProgress) {
            active
        } else {
            list.firstOrNull { !it.isCompletedForProgress }
        }
        if (next != null) {
            setActiveActivityNumber(next.activityNumber)
            if (next.status == ActivityStatus.PENDING) {
                updateActivityRecord(next.copy(status = ActivityStatus.IN_PROGRESS, lastErrorMessage = null))
            }
            setRunState(
                AssistantRunState.RUNNING,
                "Assisting Activity #${next.activityNumber}. Open the official app to proceed."
            )
            _unfamiliarScreenPrompt.value = null
            return _activities.value.firstOrNull { it.activityNumber == next.activityNumber }
        } else {
            setRunState(
                AssistantRunState.PAUSED,
                "All 20 activities are already saved or submitted."
            )
            return null
        }
    }

    @Synchronized
    fun updateActivityDetails(activityNumber: Int, title: String, note: String) {
        val record = getActivity(activityNumber) ?: return
        updateActivityRecord(
            record.copy(
                title = title.ifBlank { "Daily Activity #$activityNumber" },
                note = note
            )
        )
    }

    @Synchronized
    fun markBeforePhotoCapturedAndStartTimer(activityNumber: Int): Long {
        val now = System.currentTimeMillis()
        val endsAtWall = now + PHOTO_WAIT_SECONDS * 1000L
        val record = getActivity(activityNumber) ?: return endsAtWall
        updateActivityRecord(
            record.copy(
                status = ActivityStatus.WAITING_AFTER_TIMER,
                beforePhotoCapturedAtMs = now,
                afterTimerEndsWallMs = endsAtWall,
                lastErrorMessage = null
            )
        )
        _timerState.value = TimerUiState(
            isRunning = true,
            activityNumber = activityNumber,
            remainingSeconds = PHOTO_WAIT_SECONDS,
            totalSeconds = PHOTO_WAIT_SECONDS,
            isFinishedReadyForAfterPhoto = false
        )
        setAutomationStatusMessage("Before photo logged for Activity #$activityNumber. 2-minute countdown active.")
        return endsAtWall
    }

    fun updateTimerTick(activityNumber: Int, remainingSeconds: Int) {
        _timerState.value = TimerUiState(
            isRunning = remainingSeconds > 0,
            activityNumber = activityNumber,
            remainingSeconds = remainingSeconds.coerceAtLeast(0),
            totalSeconds = PHOTO_WAIT_SECONDS,
            isFinishedReadyForAfterPhoto = remainingSeconds <= 0
        )
    }

    @Synchronized
    fun markTimerCompleted(activityNumber: Int) {
        val record = getActivity(activityNumber)
        if (record != null && record.status == ActivityStatus.WAITING_AFTER_TIMER) {
            updateActivityRecord(record.copy(status = ActivityStatus.READY_FOR_AFTER_PHOTO))
        }
        _timerState.value = TimerUiState(
            isRunning = false,
            activityNumber = activityNumber,
            remainingSeconds = 0,
            totalSeconds = PHOTO_WAIT_SECONDS,
            isFinishedReadyForAfterPhoto = true
        )
        setAutomationStatusMessage("2 minutes elapsed for Activity #$activityNumber! Capture the genuine After photo in the official app.")
    }

    @Synchronized
    fun markAfterPhotoCaptured(activityNumber: Int): Boolean {
        val record = getActivity(activityNumber) ?: return false
        if (record.beforePhotoCapturedAtMs == null) {
            return false
        }
        val now = System.currentTimeMillis()
        updateActivityRecord(
            record.copy(
                status = ActivityStatus.READY_TO_REVIEW,
                afterPhotoCapturedAtMs = now,
                lastErrorMessage = null
            )
        )
        _timerState.value = TimerUiState(isRunning = false, activityNumber = null)
        setAutomationStatusMessage("After photo recorded for Activity #$activityNumber. Review details before saving.")
        return true
    }

    @Synchronized
    fun setActivityReviewed(activityNumber: Int, reviewed: Boolean) {
        val record = getActivity(activityNumber) ?: return
        updateActivityRecord(record.copy(userReviewedBeforeSave = reviewed))
    }

    @Synchronized
    fun confirmActivitySavedInOfficialApp(activityNumber: Int): Result<DailyActivityRecord> {
        val record = getActivity(activityNumber)
            ?: return Result.failure(IllegalArgumentException("Activity #$activityNumber not found"))
        if (record.beforePhotoCapturedAtMs == null || record.afterPhotoCapturedAtMs == null) {
            return Result.failure(IllegalStateException("Both genuine Before and After photos must be captured first."))
        }
        if (!record.userReviewedBeforeSave) {
            return Result.failure(IllegalStateException("Please review the activity details before confirming Save."))
        }
        val updated = record.copy(
            status = ActivityStatus.SAVED,
            savedVerifiedAtMs = System.currentTimeMillis(),
            lastErrorMessage = null
        )
        updateActivityRecord(updated)
        advancePointerToNextIncomplete()
        setAutomationStatusMessage("Activity #$activityNumber verified as SAVED.")
        return Result.success(updated)
    }

    @Synchronized
    fun confirmSingleActivitySubmitted(activityNumber: Int, officialConfirmationNote: String): Result<DailyActivityRecord> {
        val record = getActivity(activityNumber)
            ?: return Result.failure(IllegalArgumentException("Activity #$activityNumber not found"))
        if (record.beforePhotoCapturedAtMs == null || record.afterPhotoCapturedAtMs == null) {
            return Result.failure(IllegalStateException("Both genuine Before and After photos are required before submitting."))
        }
        if (!record.userReviewedBeforeSave) {
            return Result.failure(IllegalStateException("Please review the activity before confirming submission."))
        }
        val now = System.currentTimeMillis()
        val updated = record.copy(
            status = ActivityStatus.SUBMITTED,
            savedVerifiedAtMs = record.savedVerifiedAtMs ?: now,
            submittedVerifiedAtMs = now,
            lastErrorMessage = null
        )
        updateActivityRecord(updated)
        advancePointerToNextIncomplete()
        setAutomationStatusMessage("Activity #$activityNumber confirmed SUBMITTED ($officialConfirmationNote).")
        return Result.success(updated)
    }

    @Synchronized
    fun markActivityNeedsAttention(activityNumber: Int, reason: String) {
        val record = getActivity(activityNumber) ?: return
        updateActivityRecord(
            record.copy(
                status = ActivityStatus.NEEDS_ATTENTION,
                lastErrorMessage = reason
            )
        )
    }

    @Synchronized
    fun confirmBatchSubmitAll(officialConfirmationNote: String): Result<Int> {
        val dateKey = _todayDateKey.value
        val session = dbHelper.getBatchSession(dateKey)
        if (session.submissionLocked && session.submittedBatchAtMs != null) {
            return Result.failure(
                IllegalStateException("Today's batch was already confirmed submitted. Duplicate submission is blocked.")
            )
        }
        val list = dbHelper.getActivitiesForDate(dateKey)
        val savedActivities = list.filter { it.status == ActivityStatus.SAVED }
        if (savedActivities.isEmpty()) {
            return Result.failure(IllegalStateException("No saved activities ready for Submit All."))
        }
        val now = System.currentTimeMillis()
        savedActivities.forEach { act ->
            dbHelper.updateActivity(
                act.copy(
                    status = ActivityStatus.SUBMITTED,
                    submittedVerifiedAtMs = now,
                    lastErrorMessage = null
                )
            )
        }
        val updatedSession = BatchSessionRecord(
            dateKey = dateKey,
            submissionLocked = true,
            submittedBatchAtMs = now,
            officialConfirmationNote = officialConfirmationNote.ifBlank { "Confirmed by user inside official PITB app" }
        )
        dbHelper.updateBatchSession(updatedSession)
        refreshAll()
        if (_summary.value.submittedCount == 20) {
            setRunState(AssistantRunState.COMPLETED_BATCH, "All 20 activities verified as SUBMITTED.")
        } else {
            setAutomationStatusMessage("Verified batch submission of ${savedActivities.size} saved activities.")
        }
        return Result.success(savedActivities.size)
    }

    @Synchronized
    fun resetTodayProgress() {
        val dateKey = currentDateKey()
        dbHelper.resetDaySession(dateKey)
        setActiveActivityNumber(1)
        _timerState.value = TimerUiState()
        setRunState(AssistantRunState.IDLE, "Daily progress reset for $dateKey.")
        refreshAll()
    }

    fun saveFieldTemplate(template: ConfirmedFieldTemplate) {
        dbHelper.upsertFieldTemplate(template.copy(updatedAtMs = System.currentTimeMillis()))
        _fieldTemplates.value = dbHelper.getFieldTemplates()
    }

    fun deleteFieldTemplate(id: Long) {
        dbHelper.deleteFieldTemplate(id)
        _fieldTemplates.value = dbHelper.getFieldTemplates()
    }

    fun getActivity(activityNumber: Int): DailyActivityRecord? {
        return _activities.value.firstOrNull { it.activityNumber == activityNumber }
    }

    private fun updateActivityRecord(record: DailyActivityRecord) {
        dbHelper.updateActivity(record)
        val updatedList = dbHelper.getActivitiesForDate(record.dateKey)
        _activities.value = updatedList
        _summary.value = computeSummary(updatedList)
    }

    private fun advancePointerToNextIncomplete() {
        val next = _activities.value.firstOrNull { !it.isCompletedForProgress }
        if (next != null) {
            setActiveActivityNumber(next.activityNumber)
        }
    }

    private fun loadRunState(): AssistantRunState {
        val name = prefs.getString(KEY_RUN_STATE, AssistantRunState.IDLE.name)
        return runCatching { AssistantRunState.valueOf(name ?: "") }
            .getOrDefault(AssistantRunState.IDLE)
    }

    private fun loadSubmissionMode(): SubmissionMode {
        val name = prefs.getString(KEY_SUBMISSION_MODE, SubmissionMode.SAVE_ALL.name)
        return runCatching { SubmissionMode.valueOf(name ?: "") }
            .getOrDefault(SubmissionMode.SAVE_ALL)
    }

    private fun loadTargetAppConfig(): TargetAppConfig {
        return TargetAppConfig(
            packageName = prefs.getString(KEY_TARGET_PKG, null),
            appLabel = prefs.getString(KEY_TARGET_LABEL, null),
            versionName = prefs.getString(KEY_TARGET_VERSION, null)
        )
    }

    private fun loadActiveActivityNumber(): Int {
        return prefs.getInt(KEY_ACTIVE_ACTIVITY, 1).coerceIn(1, 20)
    }

    companion object {
        const val PHOTO_WAIT_SECONDS = 120 // Exact 2-minute genuine interval
        private const val PREFS_NAME = "anti_dengue_assistant_prefs"
        private const val KEY_RUN_STATE = "run_state"
        private const val KEY_SUBMISSION_MODE = "submission_mode"
        private const val KEY_TARGET_PKG = "target_pkg"
        private const val KEY_TARGET_LABEL = "target_label"
        private const val KEY_TARGET_VERSION = "target_version"
        private const val KEY_ACTIVE_ACTIVITY = "active_activity_num"
        private const val KEY_AUTOMATION_MSG = "automation_msg"
        private const val KEY_INSPECTOR_ENABLED = "label_inspector_enabled"

        fun currentDateKey(): String {
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        }

        fun computeSummary(list: List<DailyActivityRecord>): DashboardSummary {
            val total = list.size.coerceAtLeast(20)
            val saved = list.count { it.status == ActivityStatus.SAVED }
            val submitted = list.count { it.status == ActivityStatus.SUBMITTED }
            val completed = saved + submitted
            val pending = (total - completed).coerceAtLeast(0)
            val pct = ((completed * 100f) / total).toInt().coerceIn(0, 100)
            return DashboardSummary(
                totalCount = total,
                completedCount = completed,
                savedCount = saved,
                submittedCount = submitted,
                pendingCount = pending,
                progressPercent = pct
            )
        }
    }
}
