package com.antidengue.assistant.system

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.antidengue.assistant.accessibility.DengueAccessibilityService

object PitbAppLauncher {

    fun launchTargetApp(context: Context, packageName: String?): Result<Unit> {
        if (packageName.isNullOrBlank()) {
            return Result.failure(IllegalStateException("No official PITB app selected yet. Choose it in Setup."))
        }
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return Result.failure(
                IllegalStateException("Could not open '$packageName'. Confirm it is still installed.")
            )
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            context.startActivity(launchIntent)
        }
    }

    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expectedComponent = ComponentName(context, DengueAccessibilityService::class.java)
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        if (enabledServices.any {
                val info = it.resolveInfo?.serviceInfo
                info != null && ComponentName(info.packageName, info.name) == expectedComponent
            }
        ) {
            return true
        }

        val enabledSetting = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledSetting.split(':').any {
            ComponentName.unflattenFromString(it) == expectedComponent
        }
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openAppDetailsSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
