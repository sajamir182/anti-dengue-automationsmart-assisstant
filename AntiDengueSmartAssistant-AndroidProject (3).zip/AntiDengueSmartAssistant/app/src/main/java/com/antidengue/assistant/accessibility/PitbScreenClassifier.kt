package com.antidengue.assistant.accessibility

enum class PitbScreenType(val displayName: String) {
    AUTH_OR_OTP_SCREEN("Login / OTP Protected Screen"),
    HOME_OR_ACTIVITY_LIST("Official App Home / Activity List"),
    ACTIVITY_FORM("Activity Details Form"),
    BEFORE_PHOTO_STEP("Before Photo Step"),
    AFTER_PHOTO_STEP("After Photo Step"),
    SAVE_CONFIRMATION("Save Activity Confirmation"),
    SUBMIT_ALL_SCREEN("Batch Submit All Screen"),
    SUCCESS_CONFIRMATION("Official App Success Confirmation"),
    ERROR_OR_NETWORK_FAILURE("Error or Network Warning"),
    UNFAMILIAR_SCREEN("Unfamiliar Screen")
}

data class AccessibleNodeDescriptor(
    val className: String,
    val viewIdResourceName: String,
    val text: String,
    val contentDescription: String,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isPassword: Boolean
) {
    val combinedHint: String
        get() = listOf(text, contentDescription, viewIdResourceName)
            .filter { it.isNotBlank() }
            .joinToString(" ")
            .lowercase()
}

data class PitbWindowSnapshot(
    val packageName: String,
    val nodes: List<AccessibleNodeDescriptor>
) {
    val fullVisibleTextLower: String
        get() = nodes
            .filterNot { it.isPassword }
            .joinToString(" ") { "${it.text} ${it.contentDescription} ${it.viewIdResourceName}" }
            .lowercase()
}

object PitbScreenClassifier {

    private val authKeywords = listOf(
        "password", "passcode", "otp", "verification code", "cnic", "sign in", "login", "log in", "pin code"
    )
    private val errorKeywords = listOf(
        "no internet", "network error", "connection failed", "timeout", "unable to connect",
        "server error", "try again", "failed to submit", "offline"
    )
    private val successKeywords = listOf(
        "successfully saved", "saved successfully", "submitted successfully", "successfully submitted",
        "record saved", "activity saved", "upload complete", "sync completed"
    )
    private val submitAllKeywords = listOf(
        "submit all", "sync all", "upload all", "pending sync", "pending submission", "submit saved"
    )
    private val afterPhotoKeywords = listOf(
        "after photo", "after image", "capture after", "take after", "post activity photo"
    )
    private val beforePhotoKeywords = listOf(
        "before photo", "before image", "capture before", "take before", "pre activity photo"
    )
    private val savePromptKeywords = listOf(
        "save activity", "save draft", "save locally", "save record", "confirm save"
    )
    private val formKeywords = listOf(
        "activity", "location", "remarks", "category", "larva", "breeding", "spot", "ward", "union council", "uc", "tehsil"
    )
    private val listKeywords = listOf(
        "activities", "dashboard", "new activity", "add activity", "daily target", "dengue"
    )

    fun classify(snapshot: PitbWindowSnapshot): PitbScreenType {
        if (snapshot.nodes.isEmpty()) return PitbScreenType.UNFAMILIAR_SCREEN

        val hasPasswordField = snapshot.nodes.any { it.isPassword }
        val text = snapshot.fullVisibleTextLower

        if (hasPasswordField || authKeywords.any { text.contains(it) }) {
            return PitbScreenType.AUTH_OR_OTP_SCREEN
        }
        if (errorKeywords.any { text.contains(it) }) {
            return PitbScreenType.ERROR_OR_NETWORK_FAILURE
        }
        if (successKeywords.any { text.contains(it) }) {
            return PitbScreenType.SUCCESS_CONFIRMATION
        }
        if (submitAllKeywords.any { text.contains(it) }) {
            return PitbScreenType.SUBMIT_ALL_SCREEN
        }
        if (afterPhotoKeywords.any { text.contains(it) }) {
            return PitbScreenType.AFTER_PHOTO_STEP
        }
        if (beforePhotoKeywords.any { text.contains(it) }) {
            return PitbScreenType.BEFORE_PHOTO_STEP
        }
        if (savePromptKeywords.any { text.contains(it) }) {
            return PitbScreenType.SAVE_CONFIRMATION
        }

        val editableCount = snapshot.nodes.count { it.isEditable && !it.isPassword }
        if (editableCount > 0 && formKeywords.any { text.contains(it) }) {
            return PitbScreenType.ACTIVITY_FORM
        }
        if (listKeywords.any { text.contains(it) }) {
            return PitbScreenType.HOME_OR_ACTIVITY_LIST
        }

        return PitbScreenType.UNFAMILIAR_SCREEN
    }

    fun isSensitiveCredentialNode(node: AccessibleNodeDescriptor): Boolean {
        if (node.isPassword) return true
        val hint = node.combinedHint
        return authKeywords.any { hint.contains(it) }
    }
}
