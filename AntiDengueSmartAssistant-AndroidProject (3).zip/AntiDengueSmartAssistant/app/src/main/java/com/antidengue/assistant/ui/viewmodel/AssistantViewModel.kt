package com.antidengue.assistant.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.antidengue.assistant.AntiDengueApp
import com.antidengue.assistant.data.model.AssistantRunState
import com.antidengue.assistant.data.model.ConfirmedFieldTemplate
import com.antidengue.assistant.data.model.SubmissionMode
import com.antidengue.assistant.data.model.TargetAppConfig
import com.antidengue.assistant.system.DetectedInstalledApp
import com.antidengue.assistant.system.InstalledAppsDetector
import com.antidengue.assistant.system.PitbAppLauncher
import com.antidengue.assistant.timer.PhotoTimerForegroundService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AntiDengueApp
    val repository = app.repository
    val connectivityMonitor = app.connectivityMonitor

    val todayDateKey = repository.todayDateKey
    val activities = repository.activities
    val summary = repository.summary
    val runState = repository.runState
    val submissionMode = repository.submissionMode
    val targetAppConfig = repository.targetAppConfig
    val fieldTemplates = repository.fieldTemplates
    val batchSession = repository.batchSession
    val timerState = repository.timerState
    val activeActivityNumber = repository.activeActivityNumber
    val automationStatusMessage = repository.automationStatusMessage
    val unfamiliarScreenPrompt = repository.unfamiliarScreenPrompt
    val lastInspectedLabels = repository.lastInspectedLabels
    val labelInspectorEnabled = repository.labelInspectorEnabled
    val networkStatus = connectivityMonitor.status

    private val _installedApps = MutableStateFlow<List<DetectedInstalledApp>>(emptyList())
    val installedApps: StateFlow<List<DetectedInstalledApp>> = _installedApps.asStateFlow()

    private val _isAccessibilityEnabled = MutableStateFlow(false)
    val isAccessibilityEnabled: StateFlow<Boolean> = _isAccessibilityEnabled.asStateFlow()

    private val _uiFeedbackBanner = MutableStateFlow<String?>(null)
    val uiFeedbackBanner: StateFlow<String?> = _uiFeedbackBanner.asStateFlow()

    init {
        refreshSystemStatus()
    }

    fun refreshSystemStatus() {
        _isAccessibilityEnabled.value = PitbAppLauncher.isAccessibilityServiceEnabled(app)
        connectivityMonitor.refreshNow()
        repository.refreshAll()
    }

    fun scanInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val detected = InstalledAppsDetector.loadInstalledLauncherApps(app)
            _installedApps.value = detected
        }
    }

    fun selectTargetApp(detected: DetectedInstalledApp) {
        repository.setTargetApp(
            TargetAppConfig(
                packageName = detected.packageName,
                appLabel = detected.appLabel,
                versionName = detected.versionName
            )
        )
        _uiFeedbackBanner.value = "Selected official app: ${detected.appLabel} (${detected.packageName})"
    }

    fun setManualTargetPackage(packageName: String, label: String) {
        val trimmed = packageName.trim()
        if (trimmed.isEmpty()) return
        repository.setTargetApp(
            TargetAppConfig(
                packageName = trimmed,
                appLabel = label.ifBlank { trimmed },
                versionName = "Custom"
            )
        )
        _uiFeedbackBanner.value = "Target package set to $trimmed"
    }

    fun startOrResumeAssistant() {
        if (targetAppConfig.value.packageName.isNullOrBlank()) {
            _uiFeedbackBanner.value = "Select the official Punjab Anti-Dengue app in Setup first."
            return
        }
        val next = repository.startOrResumeNextPendingActivity()
        if (next != null) {
            _uiFeedbackBanner.value = "Assistant active on Activity #${next.activityNumber}."
        }
    }

    fun pauseAssistant() {
        repository.setRunState(AssistantRunState.PAUSED, "Assistant paused by user.")
    }

    fun dismissUnfamiliarPrompt() {
        repository.setUnfamiliarScreenPrompt(null)
    }

    fun openOfficialPitbApp() {
        val result = PitbAppLauncher.launchTargetApp(app, targetAppConfig.value.packageName)
        result.onFailure { err ->
            _uiFeedbackBanner.value = err.message ?: "Unable to launch target app."
        }
    }

    fun setSubmissionMode(mode: SubmissionMode) {
        repository.setSubmissionMode(mode)
    }

    fun selectActivity(activityNumber: Int) {
        repository.setActiveActivityNumber(activityNumber)
    }

    fun updateActivityDetails(activityNumber: Int, title: String, note: String) {
        repository.updateActivityDetails(activityNumber, title, note)
    }

    fun markBeforePhotoCaptured(activityNumber: Int) {
        repository.markBeforePhotoCapturedAndStartTimer(activityNumber)
        PhotoTimerForegroundService.start(app, activityNumber, 120)
        _uiFeedbackBanner.value = "2-minute countdown started for Activity #$activityNumber."
    }

    fun markAfterPhotoCaptured(activityNumber: Int) {
        val ok = repository.markAfterPhotoCaptured(activityNumber)
        if (!ok) {
            _uiFeedbackBanner.value = "Capture and record the Before photo first."
        } else {
            PhotoTimerForegroundService.stop(app)
        }
    }

    fun setActivityReviewed(activityNumber: Int, reviewed: Boolean) {
        repository.setActivityReviewed(activityNumber, reviewed)
    }

    fun confirmActivitySaved(activityNumber: Int) {
        repository.confirmActivitySavedInOfficialApp(activityNumber)
            .onSuccess {
                _uiFeedbackBanner.value = "Activity #$activityNumber marked SAVED."
            }
            .onFailure {
                _uiFeedbackBanner.value = it.message
            }
    }

    fun confirmSingleActivitySubmitted(activityNumber: Int, confirmationNote: String) {
        if (!networkStatus.value.isConnected) {
            _uiFeedbackBanner.value = "Network appears offline. Verify internet before confirming submission."
            return
        }
        repository.confirmSingleActivitySubmitted(activityNumber, confirmationNote)
            .onSuccess {
                _uiFeedbackBanner.value = "Activity #$activityNumber confirmed SUBMITTED."
            }
            .onFailure {
                _uiFeedbackBanner.value = it.message
            }
    }

    fun markNeedsAttention(activityNumber: Int, reason: String) {
        repository.markActivityNeedsAttention(activityNumber, reason)
        _uiFeedbackBanner.value = "Activity #$activityNumber flagged for attention."
    }

    fun confirmBatchSubmitAll(confirmationNote: String): Result<Int> {
        if (!networkStatus.value.isConnected) {
            val err = IllegalStateException("Cannot confirm Submit All while offline. Reconnect and verify in the official app.")
            _uiFeedbackBanner.value = err.message
            return Result.failure(err)
        }
        val res = repository.confirmBatchSubmitAll(confirmationNote)
        res.onSuccess { count ->
            _uiFeedbackBanner.value = "Confirmed submission for $count saved activities."
        }.onFailure { err ->
            _uiFeedbackBanner.value = err.message
        }
        return res
    }

    fun saveFieldTemplate(template: ConfirmedFieldTemplate) {
        repository.saveFieldTemplate(template)
        _uiFeedbackBanner.value = "Saved field template '${template.fieldLabelHint}'."
    }

    fun deleteFieldTemplate(id: Long) {
        repository.deleteFieldTemplate(id)
    }

    fun setLabelInspectorEnabled(enabled: Boolean) {
        repository.setLabelInspectorEnabled(enabled)
    }

    fun resetTodayProgress() {
        PhotoTimerForegroundService.stop(app)
        repository.resetTodayProgress()
        _uiFeedbackBanner.value = "Today's 20-activity checklist has been reset."
    }

    fun clearFeedbackBanner() {
        _uiFeedbackBanner.value = null
    }
}
