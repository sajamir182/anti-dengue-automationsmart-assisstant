package com.antidengue.assistant.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.antidengue.assistant.system.PitbAppLauncher
import com.antidengue.assistant.ui.theme.BorderHairline
import com.antidengue.assistant.ui.theme.DangerCrimson
import com.antidengue.assistant.ui.theme.PrimaryGreen
import com.antidengue.assistant.ui.theme.WarningAmber
import com.antidengue.assistant.ui.viewmodel.AssistantViewModel

@Composable
fun SetupGuideScreen(vm: AssistantViewModel) {
    val context = LocalContext.current
    val targetApp by vm.targetAppConfig.collectAsState()
    val installedApps by vm.installedApps.collectAsState()
    val accessibilityEnabled by vm.isAccessibilityEnabled.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var manualPackage by remember { mutableStateOf("") }
    var showResetConfirm by remember { mutableStateOf(false) }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Reset Today's 20 Activities?") },
            text = { Text("This clears today's local assistant checklist and batch lock on this phone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.resetTodayProgress()
                        showResetConfirm = false
                    }
                ) {
                    Text("Reset", color = DangerCrimson)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) {
            installedApps.take(15)
        } else {
            installedApps.filter {
                it.appLabel.contains(searchQuery, ignoreCase = true) ||
                    it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Accessibility Service Status
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "1. Accessibility Helper Service",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (accessibilityEnabled) {
                            "Status: ENABLED (Strictly scoped to your selected PITB app)"
                        } else {
                            "Status: DISABLED — Enable 'Anti-Dengue Smart Assistant Helper' in Android Accessibility Settings."
                        },
                        color = if (accessibilityEnabled) PrimaryGreen else WarningAmber,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { PitbAppLauncher.openAccessibilitySettings(context) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                        ) {
                            Text("Open Accessibility Settings")
                        }
                        OutlinedButton(
                            onClick = { vm.refreshSystemStatus() }
                        ) {
                            Text("Refresh")
                        }
                    }
                }
            }
        }

        // 2. Oppo ColorOS Android 9 Guidance
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "2. Oppo Android 9 Background & Sound Setup",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "• Battery Saver: Open App Info → Battery Usage → Allow Background Running so the 2-minute photo timer is never killed.\n• Sound: Ensure Notification volume is up for the 2-minute audible alert.\n• Honest Notice: Live PITB v9.4.0 screen integration must be tested on your phone; unfamiliar screens will automatically pause for manual control.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(
                        onClick = { PitbAppLauncher.openAppDetailsSettings(context) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open Assistant App Info (Battery & Permissions)")
                    }
                }
            }
        }

        // 3. Target PITB App Detector (Never hardcoded)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, BorderHairline),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "3. Select Official Punjab Anti-Dengue App",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (targetApp.packageName.isNullOrBlank()) {
                            "No app selected yet. Scan installed apps below and tap the official PITB app."
                        } else {
                            "Selected: ${targetApp.appLabel} (${targetApp.packageName} · v${targetApp.versionName})"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (targetApp.packageName.isNullOrBlank()) WarningAmber else PrimaryGreen
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { vm.scanInstalledApps() },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                        ) {
                            Text("Scan Installed Apps")
                        }
                    }
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Filter installed apps (e.g., dengue, pitb)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = manualPackage,
                            onValueChange = { manualPackage = it },
                            label = { Text("Or enter exact package ID") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedButton(
                            onClick = {
                                vm.setManualTargetPackage(manualPackage, "Official Anti-Dengue App")
                            },
                            enabled = manualPackage.isNotBlank()
                        ) {
                            Text("Set")
                        }
                    }
                }
            }
        }

        items(filteredApps, key = { it.packageName }) { appInfo ->
            val isSelected = targetApp.packageName == appInfo.packageName
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.selectTargetApp(appInfo) },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) PrimaryGreen else BorderHairline
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (appInfo.isLikelyAntiDengueMatch) {
                                "${appInfo.appLabel} (Likely Match)"
                            } else {
                                appInfo.appLabel
                            },
                            fontWeight = FontWeight.SemiBold,
                            color = if (appInfo.isLikelyAntiDengueMatch) PrimaryGreen else Color.Unspecified
                        )
                        Text(
                            text = "${appInfo.packageName} · v${appInfo.versionName}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (isSelected) {
                        Text("Selected", color = PrimaryGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 4. Reset Controls
        item {
            OutlinedButton(
                onClick = { showResetConfirm = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Reset Today's 20-Activity Checklist", color = DangerCrimson)
            }
        }
    }
}
