package com.antidengue.assistant

import android.app.Application
import com.antidengue.assistant.data.repository.AssistantRepository
import com.antidengue.assistant.network.ConnectivityMonitor

class AntiDengueApp : Application() {

    lateinit var repository: AssistantRepository
        private set

    lateinit var connectivityMonitor: ConnectivityMonitor
        private set

    override fun onCreate() {
        super.onCreate()
        repository = AssistantRepository(this)
        connectivityMonitor = ConnectivityMonitor(this)
        connectivityMonitor.startMonitoring()
    }
}
