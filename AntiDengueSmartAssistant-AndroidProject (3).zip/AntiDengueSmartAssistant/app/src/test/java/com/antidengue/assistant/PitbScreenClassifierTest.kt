package com.antidengue.assistant

import com.antidengue.assistant.accessibility.AccessibleNodeDescriptor
import com.antidengue.assistant.accessibility.AutomationCoordinator
import com.antidengue.assistant.accessibility.PitbScreenClassifier
import com.antidengue.assistant.accessibility.PitbScreenType
import com.antidengue.assistant.accessibility.PitbWindowSnapshot
import com.antidengue.assistant.data.model.ConfirmedFieldTemplate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PitbScreenClassifierTest {

    @Test
    fun `password or otp screen blocks automation`() {
        val snapshot = PitbWindowSnapshot(
            packageName = "example.pitb.app",
            nodes = listOf(
                AccessibleNodeDescriptor(
                    className = "android.widget.EditText",
                    viewIdResourceName = "example.pitb.app:id/etPassword",
                    text = "",
                    contentDescription = "Password",
                    isClickable = true,
                    isEditable = true,
                    isPassword = true
                )
            )
        )
        assertEquals(PitbScreenType.AUTH_OR_OTP_SCREEN, PitbScreenClassifier.classify(snapshot))
    }

    @Test
    fun `unknown screen falls back to UNFAMILIAR_SCREEN`() {
        val snapshot = PitbWindowSnapshot(
            packageName = "example.pitb.app",
            nodes = listOf(
                AccessibleNodeDescriptor(
                    className = "android.widget.TextView",
                    viewIdResourceName = "",
                    text = "Unexpected Dialog 99",
                    contentDescription = "",
                    isClickable = false,
                    isEditable = false,
                    isPassword = false
                )
            )
        )
        assertEquals(PitbScreenType.UNFAMILIAR_SCREEN, PitbScreenClassifier.classify(snapshot))
    }

    @Test
    fun `confirmed repeated field only fills empty non-password EditText`() {
        val nodes = listOf(
            AccessibleNodeDescriptor(
                className = "android.widget.EditText",
                viewIdResourceName = "example.pitb.app:id/etRemarks",
                text = "",
                contentDescription = "Remarks",
                isClickable = true,
                isEditable = true,
                isPassword = false
            ),
            AccessibleNodeDescriptor(
                className = "android.widget.EditText",
                viewIdResourceName = "example.pitb.app:id/etPin",
                text = "",
                contentDescription = "PIN Code",
                isClickable = true,
                isEditable = true,
                isPassword = true
            )
        )
        val templates = listOf(
            ConfirmedFieldTemplate(
                id = 1L,
                fieldLabelHint = "Remarks",
                confirmedValue = "Inspection completed",
                enabledForAutoFill = true,
                confirmedByUser = true
            ),
            ConfirmedFieldTemplate(
                id = 2L,
                fieldLabelHint = "PIN",
                confirmedValue = "1234",
                enabledForAutoFill = true,
                confirmedByUser = true
            )
        )
        val plans = AutomationCoordinator.matchTemplatesForEmptyFields(nodes, templates)
        assertEquals(1, plans.size)
        assertTrue(plans[0].labelHint == "Remarks")
    }
}
