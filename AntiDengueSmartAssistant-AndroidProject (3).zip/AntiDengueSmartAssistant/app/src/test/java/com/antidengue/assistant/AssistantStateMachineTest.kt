package com.antidengue.assistant

import com.antidengue.assistant.data.model.ActivityStatus
import com.antidengue.assistant.data.model.DailyActivityRecord
import com.antidengue.assistant.data.repository.AssistantRepository
import org.junit.Assert.assertEquals
import org.junit.Test

class AssistantStateMachineTest {

    @Test
    fun `dashboard summary computes saved submitted pending and percent accurately`() {
        val items = (1..20).map { num ->
            val status = when {
                num <= 5 -> ActivityStatus.SUBMITTED
                num <= 12 -> ActivityStatus.SAVED
                else -> ActivityStatus.PENDING
            }
            DailyActivityRecord(
                dateKey = "2026-11-15",
                activityNumber = num,
                title = "Activity #$num",
                status = status
            )
        }

        val summary = AssistantRepository.computeSummary(items)
        assertEquals(20, summary.totalCount)
        assertEquals(12, summary.completedCount)
        assertEquals(7, summary.savedCount)
        assertEquals(5, summary.submittedCount)
        assertEquals(8, summary.pendingCount)
        assertEquals(60, summary.progressPercent)
    }
}
