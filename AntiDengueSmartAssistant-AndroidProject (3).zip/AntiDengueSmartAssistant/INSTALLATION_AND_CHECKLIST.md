# Phone-Only APK Build, Oppo Android 9 Installation & Test Checklist

## 1. Important Build Environment Note
Because no Android SDK / JDK compiler is present in the web workspace environment, a pre-compiled `.apk` cannot be produced directly here. Instead, this ZIP contains the complete, ready-to-build Android Studio Kotlin project **plus** a ready-to-run GitHub Actions APK builder (`.github/workflows/build-apk.yml`) so you can produce a signed debug APK directly from your Oppo phone's browser without any computer or laptop.

---

## 2. Simplest Phone-Only Method to Build the Debug APK

### Method A: GitHub Mobile Browser + GitHub Actions (Recommended, ~3 minutes, 0 GB SDK needed on phone)
1. Download `AntiDengueSmartAssistant-AndroidProject.zip` on your Oppo phone and extract it using your Oppo **Files** app (or ZArchiver).
2. Open Chrome on your phone, sign in to **github.com** (free account), and create a **Private** repository named `anti-dengue-assistant`.
3. Tap **uploading an existing file** on GitHub (or use a mobile Git client like **MGit** / **Termux** to push the extracted `android-project` folder contents—make sure `.github/workflows/build-apk.yml` is included at the root of the repository).
4. Open the **Actions** tab in your GitHub repository on Chrome and tap **Build Debug APK → Run workflow**.
5. Wait ~2–3 minutes for the green checkmark, open the completed workflow run, scroll to **Artifacts**, and download **`AntiDengueSmartAssistant-debug-apk`**.
6. Unzip the downloaded artifact and tap `app-debug.apk` to install it on your Oppo phone.

### Method B: On-Device Build via Termux (Offline/Local on Phone, ~1.5 GB storage)
1. Install **Termux** (from F-Droid, not the outdated Play Store version).
2. Run:
   ```bash
   pkg update && pkg upgrade -y
   pkg install openjdk-17 gradle android-tools wget unzip -y
   ```
3. Install Android SDK command-line tools (`platforms;android-34`, `build-tools;34.0.0`), point `ANDROID_HOME` to it, extract the project ZIP, and run:
   ```bash
   gradle assembleDebug --no-daemon
   ```
4. The APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

---

## 3. Oppo Android 9 (ColorOS) Installation & Permission Setup

1. **Install APK**:
   - Tap `app-debug.apk` in your phone's **Files** app.
   - If prompted, enable **Allow from this source** (Settings → Security → Install Unknown Apps).
2. **Select Official PITB App**:
   - Open **Anti-Dengue Smart Assistant** → **Setup** tab → tap **Scan Installed Apps**.
   - Select the official **Punjab Anti Dengue (v9.4.0)** app from the list (or enter its package ID manually if needed).
3. **Enable Accessibility Service**:
   - In **Setup**, tap **Open Accessibility Settings**.
   - Find **Anti-Dengue Smart Assistant Helper** under Downloaded Services and toggle it **ON**.
   - Confirm the Android accessibility prompt (the service is restricted solely to the PITB package you selected).
4. **Prevent Oppo ColorOS from Killing the 2-Minute Countdown**:
   - In **Setup**, tap **Open Assistant App Info**.
   - Go to **Battery Usage / Power Saver** → enable **Allow Background Running** (and **Auto-startup** if shown in ColorOS).
   - Ensure **Notifications** and **Notification Sound / Ringtone Volume** are enabled so the 2-minute completion alert is clearly audible.

---

## 4. Test Checklist (Verify Before Field Use)

- [ ] **Persistence Check**: Start Activity #1, close the assistant completely from recent apps, reopen it, and confirm Activity #1 state and count are remembered.
- [ ] **Package Isolation Check**: With Accessibility Helper enabled, open WhatsApp, Settings, or Chrome and confirm the assistant does not touch or read unrelated apps.
- [ ] **Genuine Before Photo & 2-Minute Timer**:
  - Open official PITB app camera and capture a genuine Before photo.
  - Tap **Before Captured (Start 2m)** in the assistant.
  - Switch to another app or lock the phone screen; confirm the live countdown notification stays active.
  - Wait the full 2 minutes and verify the audible sound + notification triggers at `00:00`.
- [ ] **Genuine After Photo & Review Gate**:
  - Confirm **Confirm Activity Saved** remains disabled until both Before & After photos are recorded and the **Review** checkbox is ticked.
- [ ] **Repeated Field Templates & Privacy**:
  - Add a confirmed repeated field in the **Fields** tab and verify it never overwrites existing text or touches password/OTP fields.
  - Optionally enable **PITB Screen Label Inspector** briefly on the PITB form screen to verify/refine exact View IDs for v9.4.0.
- [ ] **Save All → Review & Confirm → Duplicate Guard**:
  - Verify **Submit All** shows Saved/Pending counts and live internet status.
  - Turn Airplane Mode ON and confirm the offline warning blocks confirmation.
  - After confirming a batch submission once, verify the duplicate-submission lock prevents accidental re-submission.
- [ ] **Unfamiliar Screen Safety Stop**:
  - Navigate to an unrecognized dialog inside the PITB app while Assistant is `RUNNING` and confirm it pauses with **Manual Assistance Required**.
